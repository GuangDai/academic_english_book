# DAY_0026 学术英语写作训练 V2.0（第 26 天 / 共 116 天）

- **所属阶段**：阶段 2：准确表达、一词多义辨析与时序/AI 基础句法（Day 26–50）
- **训练模式**：8 大熟词生义/多义词群高密度激活 + 间隔复习
- **今日目标词条数**：27 | **预定复习词条数**：24 | **总题量**：36 题（总分 103 分）
- **核心语法与句法分析**：G036 跨场景文体适配：顶会论文、学术演讲（Tech Talk）、个人陈述（SoP）与六级/雅思托福高分议论文, G005 词形变化、词缀构词与词性语法槽位匹配（名、动、形、副）, G011 主动语态与被动语态的基本结构、时态/情态变形与及物性限制
- **核心表达模式**：EP008 使用 be of + 抽象名词结构自然提升评价语域, EP002 精确区分可数样本量与不可数开销/证据

## 一、今日核心词群与熟词生义（Polysemy）精讲

| 词条 ID | 词条 (Lemma) | 词性 | 熟词日常义 vs. 学术目标义 | 核心规约搭配 | 典型学术例句与句子成分主干 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `V02201` | **revolution** | n. | **日常/基础**：n. 政治革命<br>**学术目标**：n. ① 公转周期（revolution around the star）；② 电机或关节每分钟转数（revolutions per minute）；③ 重大技术变革 | `revolutions per minute; a political revolution` | The instrument records the number of revolutions per minute.<br>*【紧凑主语】The instrument records the... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02202` | **revolution** | n. | **日常/基础**：n. 政治革命<br>**学术目标**：n. ① 公转周期（revolution around the star）；② 电机或关节每分钟转数（revolutions per minute）；③ 重大技术变革 | `a revolution in` | The archive documents a revolution in printing technology.<br>*【紧凑主语】The archive documents a... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02209` | **rise** | v./n. | **日常/基础**：基础字面义：上升<br>**学术目标**：多义项/多词性完整映射：上升；升幅（v./n.） | `rise from; rise to` | The total rose from forty to fifty.<br>*【紧凑主语】The total rose from... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02211` | **role** | n. | **日常/基础**：基础字面义：作用<br>**学术目标**：多义项/多词性完整映射：作用；角色；职责（n.） | `decisive role; challenging role` | The coordinator took on a clearly defined role in recruitment.<br>*【紧凑主语】The coordinator took on... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02214` | **rough** | adj. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：粗略的（adj.） | `a rough estimate` | The team produced a rough estimate before collecting further data.<br>*【紧凑主语】The team produced a... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02220` | **routine** | adj./n. | **日常/基础**：基础字面义：常规的<br>**学术目标**：多义项/多词性完整映射：常规的；例行活动（adj./n.） | `routine activities` | Routine activities may leave fewer written records than public ceremonies.<br>*【紧凑主语】Routine activities may leave... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02221` | **row** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：行（n.） | `the first row` | The first row contains the variable names.<br>*【紧凑主语】The first row contains... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02225` | **sample** | n. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：样本（n.） | `a representative sample; a random sample` | The sample included students from several departments.<br>*【紧凑主语】The sample included students... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02226` | **sample** | n./v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：样本；取样（n./v.） | `random sample; representative sample` | A random sample is not guaranteed to match every population characteristic.<br>*【紧凑主语】A random sample is... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02227` | **say** | adv./parenthetical | **日常/基础**：基础字面义：例如<br>**学术目标**：多义项/多词性完整映射：例如；比如（adv./parenthetical） | `by, say, Friday` | The pilot could begin by, say, Friday.<br>*【紧凑主语】The pilot could begin... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02235` | **scope** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：范围（n.） | `within the scope of; the scope of the study` | Clinical deployment is outside the scope of this review.<br>*【紧凑主语】Clinical deployment is outside... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02239` | **second-hand** | adj. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：二手的（adj.） | `second-hand books` | The student bought second-hand books from a previous cohort.<br>*【紧凑主语】The student bought second-hand... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02243` | **see** | v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：参见（v.） | `see Appendix A` | For implementation details, see Appendix A.<br>*【前置状语/条件框架】For implementation details + 【主句核心主谓宾/表】see Appendix A. （目标词“see”作 v. 核心成分；句首用简短状语设定边界，主句主语紧凑，避免头重脚轻）。* |
| `V02244` | **see** | v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：看到；由材料看出（v.） | `as can be seen from` | As can be seen from the table, several entries are missing.<br>*【前置状语/条件框架】As can be seen from the table + 【主句核心主谓宾/表】several entries are missing. （目标词“see”作 v. 核心成分；句首用简短状语设定边界，主句主语紧凑，避免头重脚轻）。* |
| `V02247` | **segment** | n. | **日常/基础**：基础字面义：分块<br>**学术目标**：多义项/多词性完整映射：分块；扇形部分（n.） | `a segment of a pie chart` | Each segment represents one category of expenditure.<br>*【紧凑主语】Each segment represents one... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02248` | **seldom** | adv. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：很少（adv.） | `seldom do` | Seldom do these records include an exact time of onset.<br>*【紧凑主语】Seldom do these records... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02249` | **select** | v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：选取（v.） | `select participants` | Participants were selected using predefined criteria.<br>*【紧凑主语】Participants were selected using... + 【核心谓语与宾补/状语后置扩展】全句共 6 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02250` | **select** | v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：选择（v.） | `select participants from a population` | We selected participants from three schools.<br>*【紧凑主语】We selected participants from... + 【核心谓语与宾补/状语后置扩展】全句共 6 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02256` | **seminar** | n. | **日常/基础**：基础字面义：研讨课<br>**学术目标**：多义项/多词性完整映射：研讨课；研讨会（n.） | `attend a seminar; participate in a seminar` | The seminar gave students time to discuss the evidence.<br>*【紧凑主语】The seminar gave students... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02260` | **senior** | n., adj. | **日常/基础**：基础字面义：四年级学生<br>**学术目标**：多义项/多词性完整映射：四年级学生；高年级的（n., adj.） | `a senior in a four-year programme` | The senior is completing her undergraduate dissertation.<br>*【紧凑主语】The senior is completing... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02262` | **sense** | n. | **日常/基础**：基础字面义：词义<br>**学术目标**：多义项/多词性完整映射：词义；含义（n.） | `in this sense; a technical sense` | The word bias has a technical sense in statistics.<br>*【紧凑主语】The word bias has... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02263` | **sequence** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：有序数列或序列（n.） | `an ordered sequence` | The sequence preserves the order of the measurements.<br>*【紧凑主语】The sequence preserves the... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02264` | **series** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：一系列数或观测（n.） | `a series of observations` | A series of observations was collected over the year.<br>*【紧凑主语】A series of observations... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02265` | **set** | n. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：集合；一组（n.） | `a set of numbers` | The set contains five distinct integers.<br>*【紧凑主语】The set contains five... + 【核心谓语与宾补/状语后置扩展】全句共 6 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02266` | **set** | v./n./adj. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：设定；确立；使处于；安排；凝固；一组；指定学习的（v./n./adj.） | `set an instrument to zero; set ground rules` | The tutor set a deadline and assigned two set texts.<br>*【紧凑主语】The tutor set a... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02278` | **shift** | n./v. | **日常/基础**：基础字面义：转移<br>**学术目标**：多义项/多词性完整映射：转移；变化（n./v.） | `a shift away from; a shift towards` | The policy marks a shift away from private car use towards public transport.<br>*【紧凑主语】The policy marks a... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V02283` | **shortcoming** | n. | **日常/基础**：基础字面义：缺点<br>**学术目标**：多义项/多词性完整映射：缺点；不足（n.） | `a shortcoming of a method` | A shortcoming of the method is its sensitivity to missing values.<br>*【紧凑主语】A shortcoming of the... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |

### 辅助语境生词提前释义（不计入目标词掌握情况）
- **archive**：档案；档案馆（n.）
- **cohort**：队列；同批群体（n.）
- **dissertation**：学位论文（n.）

## 二、36 道完整训练题（涵盖词形、搭配、辨析、去口语/去AI腔替换、尾重改写、中译英、语篇逻辑、语态与多文体微写作）

### 第 1 题 `Q_D0026_01` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 revolution (V02201) 的学术多义项与语境词形，并联动巩固 sample (V02225)。
- **关联词条**：`V02201, V02225` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：具身智能电机参数 revolutions per minute (RPM) 指“每分钟转数”；天体运行中区分 revolution（公转）与 rotation（自转）。 | 词表跨单元多义对比：[V02200 n.] 公转；旋转；革命（例：The diagram represents the planet’s revolution around the star.）；[V02201 n.] 完整一转；革命；重大变革（例：The instrument records the number of revolutions per minute.）；[V02202 n.] 重大变革；革命（例：The archive documents a revolution in printing technology.） | 句子成分结构：【紧凑主语】The instrument records the... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0026·词形与熟词生义激活 1】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“完整一转”，n.；注意区别于日常义：n. 政治革命），填写唯一准确的英文词形：
Sentence 1: The instrument records the number of ________ per minute. （句意：仪器记录每分钟的转数。）
Sentence 2 (Companion Context with 'sample'): The sample included students from several departments.

### 第 2 题 `Q_D0026_02` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 revolution (V02202) 的学术多义项与语境词形，并联动巩固 sample (V02226)。
- **关联词条**：`V02202, V02226` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：具身智能电机参数 revolutions per minute (RPM) 指“每分钟转数”；天体运行中区分 revolution（公转）与 rotation（自转）。 | 词表跨单元多义对比：[V02200 n.] 公转；旋转；革命（例：The diagram represents the planet’s revolution around the star.）；[V02201 n.] 完整一转；革命；重大变革（例：The instrument records the number of revolutions per minute.）；[V02202 n.] 重大变革；革命（例：The archive documents a revolution in printing technology.） | 句子成分结构：【紧凑主语】The archive documents a... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0026·词形与熟词生义激活 2】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“重大变革”，n.；注意区别于日常义：n. 政治革命），填写唯一准确的英文词形：
Sentence 1: The archive documents a ________ in printing technology. （句意：这个档案记录了印刷技术的一次重大变革。）
Sentence 2 (Companion Context with 'sample'): A random sample is not guaranteed to match every population characteristic.

### 第 3 题 `Q_D0026_03` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 rise (V02209) 的学术多义项与语境词形，并联动巩固 say (V02227)。
- **关联词条**：`V02209, V02227` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：过去式 rose、过去分词 risen，通常不及物。 | 句子成分结构：【紧凑主语】The total rose from... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0026·词形与熟词生义激活 3】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“上升”，v./n.；注意区别于日常义：基础字面义：上升），填写唯一准确的英文词形：
Sentence 1: The total ________ from forty to fifty. （句意：总数从四十上升至五十。）
Sentence 2 (Companion Context with 'say'): The pilot could begin by, say, Friday.

### 第 4 题 `Q_D0026_04` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 role (V02211) 的学术多义项与语境词形，并联动巩固 scope (V02235)。
- **关联词条**：`V02211, V02235` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：play a role in 与 take on a role 语义不同；pivotal 等强度词需具体依据。 | 句子成分结构：【紧凑主语】The coordinator took on... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0026·词形与熟词生义激活 4】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“作用”，n.；注意区别于日常义：基础字面义：作用），填写唯一准确的英文词形：
Sentence 1: The coordinator took on a clearly defined ________ in recruitment. （句意：协调员承担了招募中一个界定清楚的职责。）
Sentence 2 (Companion Context with 'scope'): Clinical deployment is outside the scope of this review.

### 第 5 题 `Q_D0026_05` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 rough (V02214) 的学术多义项与语境词形，并联动巩固 second-hand (V02239)。
- **关联词条**：`V02214, V02239` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：学术语境与搭配约束：此处指不精细的估算；rough还可描述粗糙表面。 | 句子成分结构：【紧凑主语】The team produced a... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0026·词形与熟词生义激活 5】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“粗略的”，adj.；注意区别于日常义：日常或通用英语近似概念），填写唯一准确的英文词形：
Sentence 1: The team produced a ________ estimate before collecting further data. （句意：团队在收集更多数据前给出了一个粗略估计。）
Sentence 2 (Companion Context with 'second-hand'): The student bought second-hand books from a previous cohort.

### 第 6 题 `Q_D0026_06` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 routine (V02220) 的学术多义项与语境词形，并联动巩固 see (V02243)。
- **关联词条**：`V02220, V02243` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：原文作形容词；mundane是本篇释义练习中的近义词。 | 句子成分结构：【紧凑主语】Routine activities may leave... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0026·词形与熟词生义激活 6】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“常规的”，adj./n.；注意区别于日常义：基础字面义：常规的），填写唯一准确的英文词形：
Sentence 1: ________ activities may leave fewer written records than public ceremonies. （句意：日常活动留下的文字记录可能少于公共仪式。）
Sentence 2 (Companion Context with 'see'): For implementation details, see Appendix A.

### 第 7 题 `Q_D0026_07` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 row 的自然搭配“the first row”并消除中式直译搭配错误。
- **关联词条**：`V02221, V02244` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：fixed_academic_phrase | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“the first row”精确表述“行”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0026·常见学术搭配 1】根据搭配类型（fixed_academic_phrase）与用法规范，使用目标词“row”（行）的规约搭配补全并写出下列完整英文学术句（表达：“第一行包含变量名称。”），使其与后句中的“see”（as can be seen from）构成自然衔接：
待完成句语义：第一行包含变量名称。（核心搭配提示：the first row）
后续衔接句：As can be seen from the table, several entries are missing.

### 第 8 题 `Q_D0026_08` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 sample 的自然搭配“a representative sample”并消除中式直译搭配错误。
- **关联词条**：`V02225, V02247` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：fixed_academic_phrase | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“a representative sample”精确表述“样本”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0026·常见学术搭配 2】根据搭配类型（fixed_academic_phrase）与用法规范，使用目标词“sample”（样本）的规约搭配补全并写出下列完整英文学术句（表达：“样本包含多个院系的学生。”），使其与后句中的“segment”（a segment of a pie chart）构成自然衔接：
待完成句语义：样本包含多个院系的学生。（核心搭配提示：a representative sample）
后续衔接句：Each segment represents one category of expenditure.

### 第 9 题 `Q_D0026_09` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 sample 的自然搭配“random sample”并消除中式直译搭配错误。
- **关联词条**：`V02226, V02248` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：fixed_academic_phrase | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“random sample”精确表述“样本；取样”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0026·常见学术搭配 3】根据搭配类型（fixed_academic_phrase）与用法规范，使用目标词“sample”（样本）的规约搭配补全并写出下列完整英文学术句（表达：“随机样本不能保证与总体的每项特征都一致。”），使其与后句中的“seldom”（seldom do）构成自然衔接：
待完成句语义：随机样本不能保证与总体的每项特征都一致。（核心搭配提示：random sample）
后续衔接句：Seldom do these records include an exact time of onset.

### 第 10 题 `Q_D0026_10` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 say 的自然搭配“by, say, Friday”并消除中式直译搭配错误。
- **关联词条**：`V02227, V02249` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：adv+adj_or_verb | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“by, say, Friday”精确表述“例如；比如”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0026·常见学术搭配 4】根据搭配类型（adv+adj_or_verb）与用法规范，使用目标词“say”（例如）的规约搭配补全并写出下列完整英文学术句（表达：“初步试验可以最迟在某个日期开始，比如周五。”），使其与后句中的“select”（select participants）构成自然衔接：
待完成句语义：初步试验可以最迟在某个日期开始，比如周五。（核心搭配提示：by, say, Friday）
后续衔接句：Participants were selected using predefined criteria.

### 第 11 题 `Q_D0026_11` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 scope 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V02235, V02250` | **语法点**：`G036`
- **成分与语境提示**：目标句意：临床部署不在本综述的讨论范围内。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0026·语境选词与多义/近义辨析 1】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 scope）：
Context: Clinical deployment is outside the ________ of this review. Furthermore, regarding 'select', we selected participants from three schools.

- A. approach
- B. aspect
- C. scope
- D. atmosphere

### 第 12 题 `Q_D0026_12` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 second-hand 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V02239, V02256` | **语法点**：`G036`
- **成分与语境提示**：目标句意：学生从上一届学生那里购买了二手书。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0026·语境选词与多义/近义辨析 2】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 second-hand）：
Context: The student bought ________ books from a previous cohort. Furthermore, regarding 'seminar', the seminar gave students time to discuss the evidence.

- A. mature
- B. medical
- C. minor
- D. second-hand

### 第 13 题 `Q_D0026_13` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 see 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V02243, V02260` | **语法点**：`G036`
- **成分与语境提示**：目标句意：实现细节参见附录 A。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0026·语境选词与多义/近义辨析 3】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 see）：
Context: For implementation details, ________ Appendix A. Furthermore, regarding 'senior', the senior is completing her undergraduate dissertation.

- A. see
- B. produce
- C. propose
- D. prove

### 第 14 题 `Q_D0026_14` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 see 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V02244, V02262` | **语法点**：`G036`
- **成分与语境提示**：目标句意：从表中可以看出，有几个条目缺失。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0026·语境选词与多义/近义辨析 4】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 seen）：
Context: As can be ________ from the table, several entries are missing. Furthermore, regarding 'sense', the word bias has a technical sense in statistics.

- A. reflect
- B. see
- C. regulate
- D. relax

### 第 15 题 `Q_D0026_15` 【单词替换】（3 分）
- **训练目标**：用精准学术词 segment (segment) 替换英文初稿中的口语/模糊表达“general thing or part”。
- **关联词条**：`V02247, V02263` | **语法点**：`G036, G034`
- **成分与语境提示**：目标语义：每个扇形部分表示一类支出。 | 熟词生义提醒：多义项/多词性完整映射：分块；扇形部分（n.）

【day_0026·去口语化与精准单词替换 1】下列英文初稿句中画线部分（`general thing or part`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“segment”的恰当词形，并写出完整修正句（需同时保留后半句中关于“sequence”的语境信息）：
English Draft: Each <u>general thing or part</u> represents one category of expenditure. (Context note: The sequence preserves the order of the measurements.)

### 第 16 题 `Q_D0026_16` 【单词替换】（3 分）
- **训练目标**：用精准学术词 seldom (Seldom) 替换英文初稿中的口语/模糊表达“in a rough way”。
- **关联词条**：`V02248, V02264` | **语法点**：`G036, G034`
- **成分与语境提示**：目标语义：这些记录很少包含准确的发病时间。 | 熟词生义提醒：精准学术定义：很少（adv.）

【day_0026·去口语化与精准单词替换 2】下列英文初稿句中画线部分（`in a rough way`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“seldom”的恰当词形，并写出完整修正句（需同时保留后半句中关于“series”的语境信息）：
English Draft: <u>in a rough way</u> do these records include an exact time of onset. (Context note: A series of observations was collected over the year.)

### 第 17 题 `Q_D0026_17` 【单词替换】（3 分）
- **训练目标**：用精准学术词 select (selected) 替换英文初稿中的口语/模糊表达“do or handle”。
- **关联词条**：`V02249, V02265` | **语法点**：`G036, G034`
- **成分与语境提示**：目标语义：参与者按预先规定的标准选取。 | 熟词生义提醒：当前单元特定学术义：选取（v.）

【day_0026·去口语化与精准单词替换 3】下列英文初稿句中画线部分（`do or handle`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“select”的恰当词形，并写出完整修正句（需同时保留后半句中关于“set”的语境信息）：
English Draft: Participants were <u>do or handle</u> using predefined criteria. (Context note: The set contains five distinct integers.)

### 第 18 题 `Q_D0026_18` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“select participants from a population”替换冗长生硬的英文草稿短语。
- **关联词条**：`V02250, V02266` | **语法点**：`G005, G034`
- **成分与语境提示**：目标规约短语：select participants from a population | 配合表达模式：【EP008】使用 be of + 抽象名词结构自然提升评价语域

【day_0026·冗余/中式词组替换 1】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“select”的核心学术短语/搭配（“select participants from a population”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: We <u>make a basic handling in a general way regarding do or handle</u> participants from three schools.
Companion Context ('set'): The tutor set a deadline and assigned two set texts. （目标句意：我们从三所学校选择了参与者。）

### 第 19 题 `Q_D0026_19` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“attend a seminar”替换冗长生硬的英文草稿短语。
- **关联词条**：`V02256, V02278` | **语法点**：`G005, G034`
- **成分与语境提示**：目标规约短语：attend a seminar | 配合表达模式：【EP008】使用 be of + 抽象名词结构自然提升评价语域

【day_0026·冗余/中式词组替换 2】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“seminar”的核心学术短语/搭配（“attend a seminar”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The <u>make a basic handling in a general way regarding general thing or part</u> gave students time to discuss the evidence.
Companion Context ('shift'): The policy marks a shift away from private car use towards public transport. （目标句意：研讨课给学生讨论证据的时间。）

### 第 20 题 `Q_D0026_20` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“a senior in a four-year programme”替换冗长生硬的英文草稿短语。
- **关联词条**：`V02260, V02283` | **语法点**：`G005, G034`
- **成分与语境提示**：目标规约短语：a senior in a four-year programme | 配合表达模式：【EP008】使用 be of + 抽象名词结构自然提升评价语域

【day_0026·冗余/中式词组替换 3】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“senior”的核心学术短语/搭配（“a senior in a four-year programme”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The <u>make a basic handling in a general way regarding general thing or part</u> is completing her undergraduate dissertation.
Companion Context ('shortcoming'): A shortcoming of the method is its sensitivity to missing values. （目标句意：该四年级学生正在完成本科毕业论文。）

### 第 21 题 `Q_D0026_21` 【句子改写】（3 分）
- **训练目标**：围绕 sense 与 revolution 训练【消除头重脚轻（Top-Heavy Subject Elimination & End-Weight）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V02262, V02201` | **语法点**：`G036, G032`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The word bias has... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：词义与句法边界：这里不指感官或判断力。

【day_0026·句子改写 1：消除头重脚轻（Top-Heavy Subject Elimination & End-Weight）】
Top-Heavy Draft: *The question of how the research team can properly handle the fact that the word bias has a technical sense in statistics. in the experiment is what we look at.*
改写指令：上方草稿主语长达十余词而谓语仅以软弱的 is what we look at 收尾（典型头重脚轻）。请遵循【尾重原则（G032）】，直接以核心行动者或研究对象作简短主语，运用目标词“sense”（搭配：in this sense）将其改写为紧凑、有力的学术句子（并结合“revolution”的语境边界）。

### 第 22 题 `Q_D0026_22` 【句子改写】（3 分）
- **训练目标**：围绕 sequence 与 revolution 训练【去除 AI 腔浮夸套话与过度表达（De-AI-ification & Concrete Precision）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V02263, V02202` | **语法点**：`G036, G033`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The sequence preserves the... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：学术语境与搭配约束：sequence 强调顺序。

【day_0026·句子改写 2：去除 AI 腔浮夸套话与过度表达（De-AI-ification & Concrete Precision）】
AI-Inflated Draft: *It is undeniably worth noting that our groundbreaking framework delves into the intricate realm of the problem and achieves an unparalleled breakthrough: The sequence preserves the order of the measurements.*
改写指令：上方草稿充斥着典型 AI 废话套话（undeniably worth noting, groundbreaking, delves into the intricate realm, unparalleled breakthrough）。请删去所有无证据支撑的浮夸修饰（G033），保留全部真实事实、否定与限定条件，用目标词“sequence”写出零 AI 痕迹、克制精准的学术句子（关联词条：revolution）。

### 第 23 题 `Q_D0026_23` 【句子改写】（3 分）
- **训练目标**：围绕 series 与 rise 训练【熟词生义激活与词性/句式转换改写（Polysemy & Syntactic Restructuring）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V02264, V02209` | **语法点**：`G036, G021`
- **成分与语境提示**：核心成分拆解：【紧凑主语】A series of observations... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：学术语境与搭配约束：series 单复数同形，单复数由上下文决定。

【day_0026·句子改写 3：熟词生义激活与词性/句式转换改写（Polysemy & Syntactic Restructuring）】
Source Statement: A series of observations was collected over the year. （中文句意：全年收集了一系列观测。）
改写指令：在不改变原句任何事实、时间、程度和谨慎语气（hedging）的前提下，利用目标词“series”（注意其学术义：精准学术定义：一系列数或观测（n.））及协同词“rise”，通过调整句法结构（如前置条件状语、转换词性或改写同位/修饰结构）写出语义完全等价的另一地道版本。

### 第 24 题 `Q_D0026_24` 【句子改写】（3 分）
- **训练目标**：围绕 set 与 role 训练【主从复合句与紧凑介词/分词短语或倒装转换（Clause Compression & Inversion）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V02265, V02211` | **语法点**：`G036, G018`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The set contains five... + 【核心谓语与宾补/状语后置扩展】全句共 6 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：一词多义与跨语境迁移对比：[V02265 n.] 集合；一组（例：The set contains five distinct integers.）；[V02266 v./n./adj.] 设定；确立；使处于；安排；凝固；一组；指定学习的（例：The tutor set a deadline and assigned two set texts.） | 本条用法约束：数学集合不强调排列顺序。

【day_0026·句子改写 4：主从复合句与紧凑介词/分词短语或倒装转换（Clause Compression & Inversion）】
Verbose Draft: *When we consider the context of the analysis, it is true that the set contains five distinct integers.*
改写指令：消除句首拖沓的从句，运用目标词“set”（搭配：a set of numbers）与紧凑的学术句法（G018/G031），将其改写为主干突出、主谓紧凑的单句（关联复习/协同词：role），严禁产生悬垂修饰或增删原意。

### 第 25 题 `Q_D0026_25` 【句子改写】（3 分）
- **训练目标**：围绕 set 与 rough 训练【跨场景语域迁移改写（AI/时序/具身智能论文 vs. 六级/雅思托福/演讲）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V02266, V02214` | **语法点**：`G036`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The tutor set a... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：一词多义与跨语境迁移对比：[V02265 n.] 集合；一组（例：The set contains five distinct integers.）；[V02266 v./n./adj.] 设定；确立；使处于；安排；凝固；一组；指定学习的（例：The tutor set a deadline and assigned two set texts.） | 本条用法约束：按词性和宾语辨义；凝固由材料性质决定，不能泛化为所有材料冷却即凝固。

【day_0026·句子改写 5：跨场景语域迁移改写（AI/时序/具身智能论文 vs. 六级/雅思托福/演讲）】
Base Observation: The tutor set a deadline and assigned two set texts. (Paired concept: 'rough' — The team produced a rough estimate before collecting further data.)
改写指令：将上方两个观察整合或改写为一句逻辑严密的复合句或分号衔接句，同时准确体现“set”与“rough”的核心用法，确保指代清晰且标点规范（杜绝 Comma Splice）。

### 第 26 题 `Q_D0026_26` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 shift (a shift away from) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V02278, V02220` | **语法点**：`G005, G031`
- **成分与语境提示**：多义与用法提示：词义与句法边界：方向用away from/towards。 | 语法焦点：【G031】句子成分精细剖析（主、谓、宾、表、定、状、补、同位语）与核心主干定位

【day_0026·中译英与句子成分构建 1（实证研究方法与数据核查场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“shift”的学术义“转移”及其搭配“a shift away from”，并兼顾协同词“routine”的语境标准）：
中文题干：这项政策体现了从私家车使用向公共交通的转移。
句子成分构建提示：【紧凑主语】The policy marks a... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 27 题 `Q_D0026_27` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 shortcoming (a shortcoming of a method) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V02283, V02221` | **语法点**：`G005, G035`
- **成分与语境提示**：多义与用法提示：词义与句法边界：可数；常复数 shortcomings。 | 语法焦点：【G035】机器学习、时间序列、生成模型与具身智能（Embodied AI）的技术表达句法

【day_0026·中译英与句子成分构建 2（机器学习、时间序列与生成模型场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“shortcoming”的学术义“缺点”及其搭配“a shortcoming of a method”，并兼顾协同词“row”的语境标准）：
中文题干：该方法的一个不足是对缺失值敏感。
句子成分构建提示：【紧凑主语】A shortcoming of the... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 28 题 `Q_D0026_28` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 revolution (revolutions per minute) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V02201, V02225` | **语法点**：`G005, G032`
- **成分与语境提示**：多义与用法提示：具身智能电机参数 revolutions per minute (RPM) 指“每分钟转数”；天体运行中区分 revolution（公转）与 rotation（自转）。 | 词表跨单元多义对比：[V02200 n.] 公转；旋转；革命（例：The diagram represents the planet’s revolution around the star.）；[V02201 n.] 完整一转；革命；重大变革（例：The instrument records the number of revolutions per minute.）；[V02202 n.] 重大变革；革命（例：The archive documents a revolution in printing technology.） | 语法焦点：【G032】消除“头重脚轻（Top-Heavy Subject）”与遵循尾重原则（End-Weight Principle）

【day_0026·中译英与句子成分构建 3（具身智能（Embodied AI）、传感器与系统约束场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“revolution”的学术义“完整一转”及其搭配“revolutions per minute”，并兼顾协同词“sample”的语境标准）：
中文题干：仪器记录每分钟的转数。
句子成分构建提示：【紧凑主语】The instrument records the... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 29 题 `Q_D0026_29` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 revolution (a revolution in) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V02202, V02226` | **语法点**：`G005, G036`
- **成分与语境提示**：多义与用法提示：具身智能电机参数 revolutions per minute (RPM) 指“每分钟转数”；天体运行中区分 revolution（公转）与 rotation（自转）。 | 词表跨单元多义对比：[V02200 n.] 公转；旋转；革命（例：The diagram represents the planet’s revolution around the star.）；[V02201 n.] 完整一转；革命；重大变革（例：The instrument records the number of revolutions per minute.）；[V02202 n.] 重大变革；革命（例：The archive documents a revolution in printing technology.） | 语法焦点：【G036】跨场景文体适配：顶会论文、学术演讲（Tech Talk）、个人陈述（SoP）与六级/雅思托福高分议论文

【day_0026·中译英与句子成分构建 4（六级/雅思托福高分议论文与学术演讲（Tech Talk）场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“revolution”的学术义“重大变革”及其搭配“a revolution in”，并兼顾协同词“sample”的语境标准）：
中文题干：这个档案记录了印刷技术的一次重大变革。
句子成分构建提示：【紧凑主语】The archive documents a... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 30 题 `Q_D0026_30` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：用包含 rise 与 second-hand 的具体机制与实例替换“只有夸张而无实例”的空洞断言。
- **关联词条**：`V02209, V02239, V02262` | **语法点**：`G036, G033`
- **成分与语境提示**：核心原则：用具体算子、样本条件与可核验实例替代空洞形容词（G033 & G028）

【day_0026·逻辑衔接与语篇组织 1：根治“只有夸张而无实例/具体指标”的空洞段落】
下列初稿开头句犯了“只有空洞夸张（hollow hyperbole）而无具体机制与实证支撑”的典型写作病灶：
Hollow Draft: *Our method is extremely great and solves all problems in a revolutionary way.*
任务要求：请摒弃上述空洞吹嘘，结合目标词条“rise”（上升）与“second-hand”（二手的），写出一段 2–3 句、有具体方法机制与明确适用范围的实证分析或议论文支撑句群（可用于 AI/时序/具身智能论文或六级/雅思托福正文段）。

### 第 31 题 `Q_D0026_31` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：通过含 role 与 see 的四句重排，掌握 Given-New 信息契约与 This + 总结名词衔接。
- **关联词条**：`V02211, V02243, V02263` | **语法点**：`G005, G009`
- **成分与语境提示**：语篇衔接规则：旧信息前置（Given-before-New）与精确指代回指

【day_0026·逻辑衔接与语篇组织 2：段落句子排序与 Given-New 指代链分析】
将下列包含目标词“role”与“see”的 4 个句子按“旧信息在前、新信息在后（Given-New Contract）”的指代逻辑排成连贯段落，并写出排序结果及关键回指词（如 This setup / these two findings）：
(1) When examining the empirical outputs, a second consideration arises: For implementation details, see Appendix A.
(2) Taken together, these two findings indicate that both protocol design and scope constraints must be reported transparently.
(3) First, we specify the methodological setup: The coordinator took on a clearly defined role in recruitment.
(4) This setup ensures that the evaluation criteria remain consistent across all test runs.

### 第 32 题 `Q_D0026_32` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：修复含 rough 与 see 段落中的逗号粘连、连接词误用与因果外推跳跃。
- **关联词条**：`V02214, V02244, V02264` | **语法点**：`G011, G023`
- **成分与语境提示**：综合诊断：标点规范（G023）+ 连接词精确语义（G028）+ 相关与因果边界（G026）

【day_0026·逻辑衔接与语篇组织 3：标点粘连（Comma Splice）与因果逻辑跳跃修复】
审阅下列包含“rough”与“see”的缺陷初稿，修正其中的【逗号粘连 / 连接词 on the contrary 误用】以及【把有限样本或仿真观察直接断言为无条件普遍因果律】两处错误，写出修正后的严谨英文句群：
Flawed Draft: *The team produced a rough estimate before collecting further data, on the contrary, as can be seen from the table, several entries are missing., which proves 100% universal causality in all real-world regimes.*

### 第 33 题 `Q_D0026_33` 【主动与被动语态】（4 分）
- **训练目标**：结合及物性边界（not_applicable）与旧新信息焦点训练 routine 与 segment 的语态选择。
- **关联词条**：`V02220, V02247, V02265` | **语法点**：`G011, G036`
- **成分与语境提示**：及物性：not_applicable | 语态规则：G011 & G020（禁止机械转换或丢失情态限定）

【day_0026·信息焦点与语态转换 1】阅读下列包含“routine”（常规的）与“segment”（分块）的学术表达：
Reference Sequence: (1) Routine activities may leave fewer written records than public ceremonies. (2) Each segment represents one category of expenditure.
改写要求：在严格保持原句时态、体、情态（如 may/can/should）及限定范围不变的前提下，根据“旧信息前置（Given-before-New）”与“施事责任明确性”原则，将第 (1) 句进行主动/被动语态转换（或重构为以核心研究对象为主语的紧凑句），使其与第 (2) 句自然衔接。

### 第 34 题 `Q_D0026_34` 【主动与被动语态】（4 分）
- **训练目标**：结合及物性边界（not_applicable）与旧新信息焦点训练 row 与 seldom 的语态选择。
- **关联词条**：`V02221, V02248, V02266` | **语法点**：`G011, G036`
- **成分与语境提示**：及物性：not_applicable | 语态规则：G011 & G020（禁止机械转换或丢失情态限定）

【day_0026·信息焦点与语态转换 2】阅读下列包含“row”（行）与“seldom”（很少）的学术表达：
Reference Sequence: (1) The first row contains the variable names. (2) Seldom do these records include an exact time of onset.
改写要求：在严格保持原句时态、体、情态（如 may/can/should）及限定范围不变的前提下，根据“旧信息前置（Given-before-New）”与“施事责任明确性”原则，将第 (1) 句进行主动/被动语态转换（或重构为以核心研究对象为主语的紧凑句），使其与第 (2) 句自然衔接。

### 第 35 题 `Q_D0026_35` 【独立微型写作】（5 分）
- **训练目标**：在 AI/时序/生成建模/具身智能场景下运用 sample、select 撰写零 AI 腔的技术微段落。
- **关联词条**：`V02225, V02249, V02278, V02239` | **语法点**：`G036, G032, G033`
- **成分与语境提示**：专业方向适配：ML / Time Series / Generative / Embodied AI | 语法：G032 & G035 | 模式：EP008

【day_0026·独立微型写作 1：深度学习 / 时间序列 / 生成模型 / 具身智能（Embodied AI）技术微段落（45–80 词，2–3 句）】
应用场景：顶会论文（NeurIPS / ICLR / CoRL / TPAMI）的方法描述、消融实验分析或口头技术报告（Tech Talk）。
写作要求：围绕以下候选目标词群中的至少 2–3 个词条（sample（样本）、select（选取）、shift（转移）、second-hand（二手的）），写出一段 2–3 句、紧凑自然的英文技术微段落：
1. 必须体现这些词在学术/技术语境下的准确含义与规约搭配（严防熟词生义误用）；
2. 主干清晰（主谓紧凑，长修饰语后置，彻底杜绝头重脚轻）；
3. 零 AI 腔（严禁使用 delve into / tapestry / groundbreaking / unparalleled 等空洞套话，直接用具体假设、分布、滞后项、轨迹或误差指标说话）。

### 第 36 题 `Q_D0026_36` 【独立微型写作】（5 分）
- **训练目标**：撰写融合 sample、select 与 -proof 的 3–5 句六级/雅思托福/演讲实证论证段落。
- **关联词条**：`V02226, V02250, V02283, V00011` | **语法点**：`G005, G028, G036`
- **成分与语境提示**：文体适配：CET-6 / IELTS / TOEFL Essay & Academic Speech | 语法：G005 & G036

【day_0026·独立微型写作 2：六级 / 雅思托福高分议论文与学术演讲（Tech Talk）完整段落写作（65–110 词，3–5 句）】
应用场景：英语六级（CET-6）、雅思大作文（IELTS Task 2）、托福独立写作或学术会议主题演讲。
写作要求：围绕“科技/教育/公共政策中的可及性、成本权衡与实证评估”主题，运用以下词群中的至少 3 个词条（sample（样本）、select（选择）、shortcoming（缺点）、-proof（防…）），写出一段 3–5 句、逻辑严密的完整段落：
1. 结构必须包含：【明确主题句（Topic Sentence）】+【具体作用机制解释（Mechanism）】+【真实可感的具体实例/数据场景（Concrete Instance，严禁只有夸张口号而无实例）】+【让步或边界限定句（Concession/Qualification）】；
2. 运用语法规则【G005】（词形变化、词缀构词与词性语法槽位匹配（名、动、形、副））与表达模式【EP002】（精确区分可数样本量与不可数开销/证据）；
3. 句式自然地道，杜绝死板模板句与头重脚轻。

