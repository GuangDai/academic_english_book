# DAY_0108 学术英语写作训练 V2.0（第 108 天 / 共 116 天）

- **所属阶段**：阶段 4：顶会论文、具身智能/生成建模、学术演讲与全周期综合复习（Day 76–116）
- **训练模式**：末期词汇全周期复习与多文体（AI论文/演讲/六级/雅思托福）综合实战
- **今日目标词条数**：0 | **预定复习词条数**：24 | **总题量**：36 题（总分 103 分）
- **核心语法与句法分析**：G036 跨场景文体适配：顶会论文、学术演讲（Tech Talk）、个人陈述（SoP）与六级/雅思托福高分议论文, G005 词形变化、词缀构词与词性语法槽位匹配（名、动、形、副）, G011 主动语态与被动语态的基本结构、时态/情态变形与及物性限制
- **核心表达模式**：EP012 显式声明模型假设、研究范围与成立前提, EP015 章节过渡与Given-New指代衔接（This + 总结名词）

## 一、今日核心词群与熟词生义（Polysemy）精讲

| 词条 ID | 词条 (Lemma) | 词性 | 熟词日常义 vs. 学术目标义 | 核心规约搭配 | 典型学术例句与句子成分主干 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `V00697` | **delve** | v. | **日常/基础**：基础字面义：深入探究<br>**学术目标**：多义项/多词性完整映射：深入探究；仔细调查（v.） | `delve into a question; delve into the mechanisms` | The next section delves into the assumptions behind the estimator.<br>*【紧凑主语】The next section delves... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00756` | **dilate** | v. | **日常/基础**：基础字面义：使扩大<br>**学术目标**：多义项/多词性完整映射：使扩大；扩张；按比例放大（v.） | `dilate a pupil; dilate a shape` | A geometric dilation with scale factor two doubles every distance from the centre.<br>*【紧凑主语】A geometric dilation with... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00776` | **disentangle** | v. | **日常/基础**：基础字面义：分离交织因素<br>**学术目标**：多义项/多词性完整映射：分离交织因素；理清相互纠缠的关系（v.） | `disentangle effects; disentangle A from B` | The study design aims to disentangle the effect of training from prior experience.<br>*【紧凑主语】The study design aims... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00846` | **efficacy** | n. | **日常/基础**：基础字面义：在规定或理想条件下产生预期效果的能力<br>**学术目标**：多义项/多词性完整映射：在规定或理想条件下产生预期效果的能力；效力（n.） | `treatment efficacy; evaluate efficacy` | A controlled trial can evaluate the efficacy of an intervention under specified conditions.<br>*【紧凑主语】A controlled trial can... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00879` | **encompassing** | v. | **日常/基础**：基础字面义：包含<br>**学术目标**：多义项/多词性完整映射：包含；涵盖（v.） | `encompass several methods; an encompassing framework` | The review encompasses both experimental and observational approaches.<br>*【紧凑主语】The review encompasses both... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00893` | **ensemble** | n. | **日常/基础**：基础字面义：集成<br>**学术目标**：多义项/多词性完整映射：集成；多个预测成员或模型的组合；一组系统或成员（n.） | `ensemble forecast; ensemble of models` | An ensemble forecast can combine information from several models.<br>*【紧凑主语】An ensemble forecast can... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00894` | **entangled** | adj.; v.（过去式/过去分词） | **日常/基础**：基础字面义：交织的<br>**学术目标**：多义项/多词性完整映射：交织的；纠缠的；被卷入的（adj.; v.（过去式/过去分词）） | `entangled factors; be entangled with` | The effects of income and neighbourhood conditions may be entangled in observational data.<br>*【紧凑主语】The effects of income... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00896` | **entropy** | n. | **日常/基础**：基础字面义：熵<br>**学术目标**：多义项/多词性完整映射：熵；信息论中分布不确定性的量；热力学中的状态量（n.） | `Shannon entropy; differential entropy` | Shannon entropy quantifies uncertainty in a discrete probability distribution.<br>*【紧凑主语】Shannon entropy quantifies uncertainty... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00909` | **ergodicity** | n. | **日常/基础**：基础字面义：遍历性<br>**学术目标**：多义项/多词性完整映射：遍历性；在相应条件下时间平均能够反映总体平均的性质（n.） | `ergodicity assumption; stationarity and ergodicity` | For a stationary ergodic process with E<br>*【紧凑主语】For a stationary ergodic... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00960` | **exogenous** | adj. | **日常/基础**：基础字面义：外源的<br>**学术目标**：多义项/多词性完整映射：外源的；由所研究系统之外决定的；满足指定外生性条件的（adj.） | `exogenous input; exogenous regressor` | Calling a predictor exogenous requires a precise statement of its relationship to the model's disturbances.<br>*【紧凑主语】Calling a predictor exogenous... + 【核心谓语与宾补/状语后置扩展】全句共 15 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00994` | **extrapolate** | v. | **日常/基础**：基础字面义：外推<br>**学术目标**：多义项/多词性完整映射：外推；据已有信息推断范围之外的情况（v.） | `extrapolate from observations; extrapolate beyond the training range` | We should not extrapolate from a single district to the entire country without justification.<br>*【紧凑主语】We should not extrapolate... + 【核心谓语与宾补/状语后置扩展】全句共 14 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V00995` | **extrapolation** | n. | **日常/基础**：基础字面义：外推<br>**学术目标**：多义项/多词性完整映射：外推；向已观测范围之外作推断（n.） | `extrapolation beyond the data; linear extrapolation` | Extrapolation beyond the observed age range requires additional justification.<br>*【紧凑主语】Extrapolation beyond the observed... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01145` | **ground-truth** | n. phrase | **日常/基础**：基础字面义：真实参考值<br>**学术目标**：多义项/多词性完整映射：真实参考值；作为评估依据的参考标签或测量（n. phrase） | `ground-truth label; compare with ground truth` | The predictions are compared with ground-truth labels that were checked by two annotators.<br>*【紧凑主语】The predictions are compared... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01157` | **halve** | v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：使减半；减为一半（v.） | `halve the sample size; halve the processing time` | Halving the sampling interval doubles the sampling frequency.<br>*【紧凑主语】Halving the sampling interval... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01158` | **halve** | v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：减半（v.） | `halve the cost; the value halved` | The hypothetical grant would halve the registration fee.<br>*【紧凑主语】The hypothetical grant would... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01174` | **heuristic** | n.; adj. | **日常/基础**：基础字面义：启发式方法<br>**学术目标**：多义项/多词性完整映射：启发式方法；经验性的求解规则；启发式的（n.; adj.） | `heuristic algorithm; heuristic argument` | The heuristic selects a feasible candidate but does not guarantee a global optimum.<br>*【紧凑主语】The heuristic selects a... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |

### 辅助语境生词提前释义（不计入目标词掌握情况）
- **estimator**：估计量（n.）
- **ergodic**：遍历的（adj.）
- **annotators**：标注者（n. pl.）
- **sampling**：抽样；采样（n.）
- **Euclidean**：欧几里得的（adj.）

## 二、36 道完整训练题（涵盖词形、搭配、辨析、去口语/去AI腔替换、尾重改写、中译英、语篇逻辑、语态与多文体微写作）

### 第 1 题 `Q_D0108_01` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 delve (V00697) 的学术多义项与语境词形，并联动巩固 entropy (V00896)。
- **关联词条**：`V00697, V00896` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：通常用 delve into；在学术文体中可以使用，但 examine/analyse 更直接，避免把它当作装饰性动词。 | 句子成分结构：【紧凑主语】The next section delves... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0108·词形与熟词生义激活 1】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“深入探究”，v.；注意区别于日常义：基础字面义：深入探究），填写唯一准确的英文词形：
Sentence 1: The next section ________ into the assumptions behind the estimator. （句意：下一节详细探究该估计量所依赖的假设。）
Sentence 2 (Companion Context with 'entropy'): Shannon entropy quantifies uncertainty in a discrete probability distribution.

### 第 2 题 `Q_D0108_02` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 dilate (V00756) 的学术多义项与语境词形，并联动巩固 ergodicity (V00909)。
- **关联词条**：`V00756, V00909` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：医学常指瞳孔或血管扩张；几何 dilation 可按比例放大或缩小，不能一律理解成只扩大。 | 句子成分结构：【紧凑主语】A geometric dilation with... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0108·词形与熟词生义激活 2】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“使扩大”，v.；注意区别于日常义：基础字面义：使扩大），填写唯一准确的英文词形：
Sentence 1: A geometric ________ with scale factor two doubles every distance from the centre. （句意：比例因子为二的几何位似变换使每一点到中心的距离加倍。）
Sentence 2 (Companion Context with 'ergodicity'): For a stationary ergodic process with E

### 第 3 题 `Q_D0108_03` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 disentangle (V00776) 的学术多义项与语境词形，并联动巩固 exogenous (V00960)。
- **关联词条**：`V00776, V00960` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：disentangle A from B；模型中称 disentangled representation 需给评估定义，分离表示不自动等于识别因果因素。 | 句子成分结构：【紧凑主语】The study design aims... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0108·词形与熟词生义激活 3】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“分离交织因素”，v.；注意区别于日常义：基础字面义：分离交织因素），填写唯一准确的英文词形：
Sentence 1: The study design aims to ________ the effect of training from prior experience. （句意：研究设计旨在分离培训的影响与既有经验的影响。）
Sentence 2 (Companion Context with 'exogenous'): Calling a predictor exogenous requires a precise statement of its relationship to the model's disturbances.

### 第 4 题 `Q_D0108_04` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 efficacy (V00846) 的学术多义项与语境词形，并联动巩固 extrapolate (V00994)。
- **关联词条**：`V00846, V00994` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：常用于试验条件下效果，effectiveness 常指实际使用条件下效果；区别依学科约定，不等于安全性或适合所有人。 | 句子成分结构：【紧凑主语】A controlled trial can... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0108·词形与熟词生义激活 4】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“在规定或理想条件下产生预期效果的能力”，n.；注意区别于日常义：基础字面义：在规定或理想条件下产生预期效果的能力），填写唯一准确的英文词形：
Sentence 1: A controlled trial can evaluate the ________ of an intervention under specified conditions. （句意：对照试验能够在指定条件下评估一项干预的效力。）
Sentence 2 (Companion Context with 'extrapolate'): We should not extrapolate from a single district to the entire country without justification.

### 第 5 题 `Q_D0108_05` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 encompassing (V00879) 的学术多义项与语境词形，并联动巩固 extrapolation (V00995)。
- **关联词条**：`V00879, V00995` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：原词 encompassing 是现在分词或形容词；encompass 及物，不接 of；涵盖范围应明示，不能暗示所有情况已覆盖。 | 句子成分结构：【紧凑主语】The review encompasses both... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0108·词形与熟词生义激活 5】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“包含”，v.；注意区别于日常义：基础字面义：包含），填写唯一准确的英文词形：
Sentence 1: The review ________ both experimental and observational approaches. （句意：该综述涵盖实验方法和观察方法。）
Sentence 2 (Companion Context with 'extrapolation'): Extrapolation beyond the observed age range requires additional justification.

### 第 6 题 `Q_D0108_06` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 ensemble (V00893) 的学术多义项与语境词形，并联动巩固 ground-truth (V01145)。
- **关联词条**：`V00893, V01145` | **语法点**：`G036`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：可数；模型集成可以组合不同模型，气象集合预报也可用同一模型的不同初值或扰动产生成员；集成不保证优于所有单模型；物理中的 ensemble 可指满足指定条件的一组系统。 | 句子成分结构：【紧凑主语】An ensemble forecast can... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0108·词形与熟词生义激活 6】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“集成”，n.；注意区别于日常义：基础字面义：集成），填写唯一准确的英文词形：
Sentence 1: An ________ forecast can combine information from several models. （句意：集成预测可以结合多个模型提供的信息。）
Sentence 2 (Companion Context with 'ground-truth'): The predictions are compared with ground-truth labels that were checked by two annotators.

### 第 7 题 `Q_D0108_07` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 entangled 的自然搭配“entangled factors”并消除中式直译搭配错误。
- **关联词条**：`V00894, V01157` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：adj+noun | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“entangled factors”精确表述“交织的；纠缠的；被卷入的”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0108·常见学术搭配 1】根据搭配类型（adj+noun）与用法规范，使用目标词“entangled”（交织的）的规约搭配补全并写出下列完整英文学术句（表达：“在观察数据中，收入和社区条件的影响可能交织在一起。”），使其与后句中的“halve”（halve the sample size）构成自然衔接：
待完成句语义：在观察数据中，收入和社区条件的影响可能交织在一起。（核心搭配提示：entangled factors）
后续衔接句：Halving the sampling interval doubles the sampling frequency.

### 第 8 题 `Q_D0108_08` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 entropy 的自然搭配“Shannon entropy”并消除中式直译搭配错误。
- **关联词条**：`V00896, V01158` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：fixed_academic_phrase | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“Shannon entropy”精确表述“熵；信息论中分布不确定性的量；热力学中的状态量”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0108·常见学术搭配 2】根据搭配类型（fixed_academic_phrase）与用法规范，使用目标词“entropy”（熵）的规约搭配补全并写出下列完整英文学术句（表达：“香农熵量化一个离散概率分布中的不确定性。”），使其与后句中的“halve”（halve the cost）构成自然衔接：
待完成句语义：香农熵量化一个离散概率分布中的不确定性。（核心搭配提示：Shannon entropy）
后续衔接句：The hypothetical grant would halve the registration fee.

### 第 9 题 `Q_D0108_09` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 ergodicity 的自然搭配“ergodicity assumption”并消除中式直译搭配错误。
- **关联词条**：`V00909, V01174` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：fixed_academic_phrase | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“ergodicity assumption”精确表述“遍历性；在相应条件下时间平均能够反映总体平均的性质”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0108·常见学术搭配 3】根据搭配类型（fixed_academic_phrase）与用法规范，使用目标词“ergodicity”（遍历性）的规约搭配补全并写出下列完整英文学术句（表达：“X_0”），使其与后句中的“heuristic”（heuristic algorithm）构成自然衔接：
待完成句语义：X_0（核心搭配提示：ergodicity assumption）
后续衔接句：The heuristic selects a feasible candidate but does not guarantee a global optimum.

### 第 10 题 `Q_D0108_10` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 exogenous 的自然搭配“exogenous input”并消除中式直译搭配错误。
- **关联词条**：`V00960, V01218` | **语法点**：`G036, G005`
- **成分与语境提示**：搭配类型：adj+noun | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“exogenous input”精确表述“外源的；由所研究系统之外决定的；满足指定外生性条件的”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0108·常见学术搭配 4】根据搭配类型（adj+noun）与用法规范，使用目标词“exogenous”（外源的）的规约搭配补全并写出下列完整英文学术句（表达：“把预测变量称为外生变量，需要明确说明它与模型扰动项的关系。”），使其与后句中的“immanent”（immanent in a system）构成自然衔接：
待完成句语义：把预测变量称为外生变量，需要明确说明它与模型扰动项的关系。（核心搭配提示：exogenous input）
后续衔接句：The essay examines values immanent in the institution's decision-making practices.

### 第 11 题 `Q_D0108_11` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 extrapolate 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V00994, V01244` | **语法点**：`G036`
- **成分与语境提示**：目标句意：没有论证时，我们不应从一个地区的情况外推到全国。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0108·语境选词与多义/近义辨析 1】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 extrapolate）：
Context: We should not ________ from a single district to the entire country without justification. Furthermore, regarding 'in charge of', the research coordinator is in charge of participant scheduling.

- A. extrapolate
- B. stimulate
- C. store
- D. stress

### 第 12 题 `Q_D0108_12` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 extrapolation 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V00995, V01255` | **语法点**：`G036`
- **成分与语境提示**：目标句意：超出已观测年龄范围的外推需要额外论证。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0108·语境选词与多义/近义辨析 2】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 Extrapolation）：
Context: ________ beyond the observed age range requires additional justification. Furthermore, regarding 'in general', in general, applicants should allow time for document checks.

- A. discipline
- B. extrapolation
- C. discourse
- D. discovery

### 第 13 题 `Q_D0108_13` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 ground-truth 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V01145, V01256` | **语法点**：`G036`
- **成分与语境提示**：目标句意：这些预测与由两名标注者核查过的参考标签进行比较。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0108·语境选词与多义/近义辨析 3】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 ground-truth）：
Context: The predictions are compared with ________ labels that were checked by two annotators. Furthermore, regarding 'in greater detail', the appendix examines the assumptions in greater detail.

- A. lack of
- B. learning environment
- C. ground-truth
- D. learning management system

### 第 14 题 `Q_D0108_14` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 halve 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V01157, V01257` | **语法点**：`G036`
- **成分与语境提示**：目标句意：把采样间隔减半会使采样频率加倍。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0108·语境选词与多义/近义辨析 4】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 Halving）：
Context: ________ the sampling interval doubles the sampling frequency. Furthermore, regarding 'in greater detail', we examine the assumptions in greater detail below.

- A. verify
- B. visualise
- C. welcome
- D. halve

### 第 15 题 `Q_D0108_15` 【单词替换】（3 分）
- **训练目标**：用精准学术词 halve (halve) 替换英文初稿中的口语/模糊表达“do or handle”。
- **关联词条**：`V01158, V01258` | **语法点**：`G036, G034`
- **成分与语境提示**：目标语义：假设中的资助会使注册费减半。 | 熟词生义提醒：当前单元特定学术义：减半（v.）

【day_0108·去口语化与精准单词替换 1】下列英文初稿句中画线部分（`do or handle`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“halve”的恰当词形，并写出完整修正句（需同时保留后半句中关于“in instalments”的语境信息）：
English Draft: The hypothetical grant would <u>do or handle</u> the registration fee. (Context note: The student pays the fees in instalments.)

### 第 16 题 `Q_D0108_16` 【单词替换】（3 分）
- **训练目标**：用精准学术词 heuristic (heuristic) 替换英文初稿中的口语/模糊表达“general thing or part”。
- **关联词条**：`V01174, V01259` | **语法点**：`G036, G034`
- **成分与语境提示**：目标语义：该启发式方法选择一个可行候选解，但不保证全局最优。 | 熟词生义提醒：多义项/多词性完整映射：启发式方法；经验性的求解规则；启发式的（n.; adj.）

【day_0108·去口语化与精准单词替换 2】下列英文初稿句中画线部分（`general thing or part`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“heuristic”的恰当词形，并写出完整修正句（需同时保留后半句中关于“in instalments”的语境信息）：
English Draft: The <u>general thing or part</u> selects a feasible candidate but does not guarantee a global optimum. (Context note: Participants could pay the course fee in instalments.)

### 第 17 题 `Q_D0108_17` 【单词替换】（3 分）
- **训练目标**：用精准学术词 immanent (immanent) 替换英文初稿中的口语/模糊表达“big or special”。
- **关联词条**：`V01218, V01260` | **语法点**：`G036, G034`
- **成分与语境提示**：目标语义：这篇文章考察该机构决策实践中内在的价值观。 | 熟词生义提醒：多义项/多词性完整映射：内在于某事物的；作为其固有部分存在的（adj.）

【day_0108·去口语化与精准单词替换 3】下列英文初稿句中画线部分（`big or special`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“immanent”的恰当词形，并写出完整修正句（需同时保留后半句中关于“in light of”的语境信息）：
English Draft: The essay examines values <u>big or special</u> in the institution's decision-making practices. (Context note: The team revised its plan in light of the new evidence.)

### 第 18 题 `Q_D0108_18` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“in charge of data collection”替换冗长生硬的英文草稿短语。
- **关联词条**：`V01244, V01810` | **语法点**：`G005, G034`
- **成分与语境提示**：目标规约短语：in charge of data collection | 配合表达模式：【EP012】显式声明模型假设、研究范围与成立前提

【day_0108·冗余/中式词组替换 1】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“in charge of”的核心学术短语/搭配（“in charge of data collection”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The research coordinator is <u>make a basic handling in a general way regarding do or handle</u> participant scheduling.
Companion Context ('own'): We keep archived records separate from our own notes. （目标句意：研究协调员负责安排参与者的时间。）

### 第 19 题 `Q_D0108_19` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“in general, applicants”替换冗长生硬的英文草稿短语。
- **关联词条**：`V01255, V01817` | **语法点**：`G005, G034`
- **成分与语境提示**：目标规约短语：in general, applicants | 配合表达模式：【EP012】显式声明模型假设、研究范围与成立前提

【day_0108·冗余/中式词组替换 2】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“in general”的核心学术短语/搭配（“in general, applicants”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: <u>make a basic handling in a general way regarding in a rough way</u>, applicants should allow time for document checks.
Companion Context ('parallel'): Distinct parallel straight lines do not intersect in the Euclidean plane. （目标句意：一般而言，申请者应为文件审核留出时间。）

### 第 20 题 `Q_D0108_20` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“examine in greater detail”替换冗长生硬的英文草稿短语。
- **关联词条**：`V01256, V01818` | **语法点**：`G005, G034`
- **成分与语境提示**：目标规约短语：examine in greater detail | 配合表达模式：【EP012】显式声明模型假设、研究范围与成立前提

【day_0108·冗余/中式词组替换 3】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“in greater detail”的核心学术短语/搭配（“examine in greater detail”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The appendix examines the assumptions <u>make a basic handling in a general way regarding in a rough way</u>.
Companion Context ('parallel'): There are parallels between the two institutional reforms. （目标句意：附录更详细地考察了这些假设。）

### 第 21 题 `Q_D0108_21` 【句子改写】（3 分）
- **训练目标**：围绕 in greater detail 与 delve 训练【消除头重脚轻（Top-Heavy Subject Elimination & End-Weight）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01257, V00697` | **语法点**：`G036, G032`
- **成分与语境提示**：核心成分拆解：【紧凑主语】We examine the assumptions... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：一词多义与跨语境迁移对比：[V01256 adv. phrase] 更详细地（例：The appendix examines the assumptions in greater detail.）；[V01257 状语短语] 更详细地（例：We examine the assumptions in greater detail below.） | 本条用法约束：detail 通常不可数。

【day_0108·句子改写 1：消除头重脚轻（Top-Heavy Subject Elimination & End-Weight）】
Top-Heavy Draft: *The question of how the research team can properly handle the fact that we examine the assumptions in greater detail below. in the experiment is what we look at.*
改写指令：上方草稿主语长达十余词而谓语仅以软弱的 is what we look at 收尾（典型头重脚轻）。请遵循【尾重原则（G032）】，直接以核心行动者或研究对象作简短主语，运用目标词“in greater detail”（搭配：examine assumptions in greater detail）将其改写为紧凑、有力的学术句子（并结合“delve”的语境边界）。

### 第 22 题 `Q_D0108_22` 【句子改写】（3 分）
- **训练目标**：围绕 in instalments 与 dilate 训练【去除 AI 腔浮夸套话与过度表达（De-AI-ification & Concrete Precision）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01258, V00756` | **语法点**：`G036, G033`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The student pays the... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：一词多义与跨语境迁移对比：[V01258 phrase] 分期地（例：The student pays the fees in instalments.）；[V01259 prep. phr.] 分期地（例：Participants could pay the course fee in instalments.） | 本条用法约束：美式 installments；in，不能用 on。

【day_0108·句子改写 2：去除 AI 腔浮夸套话与过度表达（De-AI-ification & Concrete Precision）】
AI-Inflated Draft: *It is undeniably worth noting that our groundbreaking framework delves into the intricate realm of the problem and achieves an unparalleled breakthrough: The student pays the fees in instalments.*
改写指令：上方草稿充斥着典型 AI 废话套话（undeniably worth noting, groundbreaking, delves into the intricate realm, unparalleled breakthrough）。请删去所有无证据支撑的浮夸修饰（G033），保留全部真实事实、否定与限定条件，用目标词“in instalments”写出零 AI 痕迹、克制精准的学术句子（关联词条：dilate）。

### 第 23 题 `Q_D0108_23` 【句子改写】（3 分）
- **训练目标**：围绕 in instalments 与 disentangle 训练【熟词生义激活与词性/句式转换改写（Polysemy & Syntactic Restructuring）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01259, V00776` | **语法点**：`G036, G021`
- **成分与语境提示**：核心成分拆解：【紧凑主语】Participants could pay the... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：一词多义与跨语境迁移对比：[V01258 phrase] 分期地（例：The student pays the fees in instalments.）；[V01259 prep. phr.] 分期地（例：Participants could pay the course fee in instalments.） | 本条用法约束：英式 instalments；美式 installments；介词 in。

【day_0108·句子改写 3：熟词生义激活与词性/句式转换改写（Polysemy & Syntactic Restructuring）】
Source Statement: Participants could pay the course fee in instalments. （中文句意：参加者可分期支付课程费。）
改写指令：在不改变原句任何事实、时间、程度和谨慎语气（hedging）的前提下，利用目标词“in instalments”（注意其学术义：当前单元特定学术义：分期地（prep. phr.））及协同词“disentangle”，通过调整句法结构（如前置条件状语、转换词性或改写同位/修饰结构）写出语义完全等价的另一地道版本。

### 第 24 题 `Q_D0108_24` 【句子改写】（3 分）
- **训练目标**：围绕 in light of 与 efficacy 训练【主从复合句与紧凑介词/分词短语或倒装转换（Clause Compression & Inversion）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01260, V00846` | **语法点**：`G036, G018`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The team revised its... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：一词多义与跨语境迁移对比：[V01260 phrase] 鉴于；根据（例：The team revised its plan in light of the new evidence.）；[V01261 prep.phr.] 鉴于；考虑到（例：The interpretation was revised in light of new evidence.） | 本条用法约束：in the light of 也成立；不自动表示因果推断。

【day_0108·句子改写 4：主从复合句与紧凑介词/分词短语或倒装转换（Clause Compression & Inversion）】
Verbose Draft: *When we consider the context of the analysis, it is true that the team revised its plan in light of the new evidence.*
改写指令：消除句首拖沓的从句，运用目标词“in light of”（搭配：revise in light of evidence）与紧凑的学术句法（G018/G031），将其改写为主干突出、主谓紧凑的单句（关联复习/协同词：efficacy），严禁产生悬垂修饰或增删原意。

### 第 25 题 `Q_D0108_25` 【句子改写】（3 分）
- **训练目标**：围绕 own 与 encompassing 训练【跨场景语域迁移改写（AI/时序/具身智能论文 vs. 六级/雅思托福/演讲）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01810, V00879` | **语法点**：`G036`
- **成分与语境提示**：核心成分拆解：【紧凑主语】We keep archived records... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：词义与句法边界：their own research中强化所属关系；不同语法体系可将own作为形容词或限定结构说明，不能把前面的their当普通形容词。

【day_0108·句子改写 5：跨场景语域迁移改写（AI/时序/具身智能论文 vs. 六级/雅思托福/演讲）】
Base Observation: We keep archived records separate from our own notes. (Paired concept: 'encompassing' — The review encompasses both experimental and observational approaches.)
改写指令：将上方两个观察整合或改写为一句逻辑严密的复合句或分号衔接句，同时准确体现“own”与“encompassing”的核心用法，确保指代清晰且标点规范（杜绝 Comma Splice）。

### 第 26 题 `Q_D0108_26` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 parallel (parallel lines) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V01817, V00893` | **语法点**：`G005, G031`
- **成分与语境提示**：多义与用法提示：一词多义与跨语境迁移对比：[V01817 adj.] 平行的（例：Distinct parallel straight lines do not intersect in the Euclidean plane.）；[V01818 n.] 相似之处（例：There are parallels between the two institutional reforms.） | 本条用法约束：需保留几何范围；一般图线相似不必严格平行。 | 语法焦点：【G031】句子成分精细剖析（主、谓、宾、表、定、状、补、同位语）与核心主干定位

【day_0108·中译英与句子成分构建 1（实证研究方法与数据核查场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“parallel”的学术义“平行的”及其搭配“parallel lines”，并兼顾协同词“ensemble”的语境标准）：
中文题干：在欧氏平面中，不重合的平行直线不相交。
句子成分构建提示：【紧凑主语】Distinct parallel straight lines... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 27 题 `Q_D0108_27` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 parallel (parallels between) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V01818, V00894` | **语法点**：`G005, G035`
- **成分与语境提示**：多义与用法提示：一词多义与跨语境迁移对比：[V01817 adj.] 平行的（例：Distinct parallel straight lines do not intersect in the Euclidean plane.）；[V01818 n.] 相似之处（例：There are parallels between the two institutional reforms.） | 本条用法约束：常用复数parallels。 | 语法焦点：【G035】机器学习、时间序列、生成模型与具身智能（Embodied AI）的技术表达句法

【day_0108·中译英与句子成分构建 2（机器学习、时间序列与生成模型场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“parallel”的学术义“相似之处”及其搭配“parallels between”，并兼顾协同词“entangled”的语境标准）：
中文题干：这两项制度改革有相似之处。
句子成分构建提示：【紧凑主语】There are parallels between... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 28 题 `Q_D0108_28` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 delve (delve into a question) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V00697, V00896` | **语法点**：`G005, G032`
- **成分与语境提示**：多义与用法提示：词义与句法边界：通常用 delve into；在学术文体中可以使用，但 examine/analyse 更直接，避免把它当作装饰性动词。 | 语法焦点：【G032】消除“头重脚轻（Top-Heavy Subject）”与遵循尾重原则（End-Weight Principle）

【day_0108·中译英与句子成分构建 3（具身智能（Embodied AI）、传感器与系统约束场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“delve”的学术义“深入探究”及其搭配“delve into a question”，并兼顾协同词“entropy”的语境标准）：
中文题干：下一节详细探究该估计量所依赖的假设。
句子成分构建提示：【紧凑主语】The next section delves... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 29 题 `Q_D0108_29` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 dilate (dilate a pupil) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V00756, V00909` | **语法点**：`G005, G036`
- **成分与语境提示**：多义与用法提示：词义与句法边界：医学常指瞳孔或血管扩张；几何 dilation 可按比例放大或缩小，不能一律理解成只扩大。 | 语法焦点：【G036】跨场景文体适配：顶会论文、学术演讲（Tech Talk）、个人陈述（SoP）与六级/雅思托福高分议论文

【day_0108·中译英与句子成分构建 4（六级/雅思托福高分议论文与学术演讲（Tech Talk）场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“dilate”的学术义“使扩大”及其搭配“dilate a pupil”，并兼顾协同词“ergodicity”的语境标准）：
中文题干：比例因子为二的几何位似变换使每一点到中心的距离加倍。
句子成分构建提示：【紧凑主语】A geometric dilation with... + 【核心谓语与宾补/状语后置扩展】全句共 13 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 30 题 `Q_D0108_30` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：用包含 disentangle 与 extrapolation 的具体机制与实例替换“只有夸张而无实例”的空洞断言。
- **关联词条**：`V00776, V00995, V01257` | **语法点**：`G036, G033`
- **成分与语境提示**：核心原则：用具体算子、样本条件与可核验实例替代空洞形容词（G033 & G028）

【day_0108·逻辑衔接与语篇组织 1：根治“只有夸张而无实例/具体指标”的空洞段落】
下列初稿开头句犯了“只有空洞夸张（hollow hyperbole）而无具体机制与实证支撑”的典型写作病灶：
Hollow Draft: *Our method is extremely great and solves all problems in a revolutionary way.*
任务要求：请摒弃上述空洞吹嘘，结合目标词条“disentangle”（分离交织因素）与“extrapolation”（外推），写出一段 2–3 句、有具体方法机制与明确适用范围的实证分析或议论文支撑句群（可用于 AI/时序/具身智能论文或六级/雅思托福正文段）。

### 第 31 题 `Q_D0108_31` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：通过含 efficacy 与 ground-truth 的四句重排，掌握 Given-New 信息契约与 This + 总结名词衔接。
- **关联词条**：`V00846, V01145, V01258` | **语法点**：`G005, G009`
- **成分与语境提示**：语篇衔接规则：旧信息前置（Given-before-New）与精确指代回指

【day_0108·逻辑衔接与语篇组织 2：段落句子排序与 Given-New 指代链分析】
将下列包含目标词“efficacy”与“ground-truth”的 4 个句子按“旧信息在前、新信息在后（Given-New Contract）”的指代逻辑排成连贯段落，并写出排序结果及关键回指词（如 This setup / these two findings）：
(1) When examining the empirical outputs, a second consideration arises: The predictions are compared with ground-truth labels that were checked by two annotators.
(2) Taken together, these two findings indicate that both protocol design and scope constraints must be reported transparently.
(3) First, we specify the methodological setup: A controlled trial can evaluate the efficacy of an intervention under specified conditions.
(4) This setup ensures that the evaluation criteria remain consistent across all test runs.

### 第 32 题 `Q_D0108_32` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：修复含 encompassing 与 halve 段落中的逗号粘连、连接词误用与因果外推跳跃。
- **关联词条**：`V00879, V01157, V01259` | **语法点**：`G011, G023`
- **成分与语境提示**：综合诊断：标点规范（G023）+ 连接词精确语义（G028）+ 相关与因果边界（G026）

【day_0108·逻辑衔接与语篇组织 3：标点粘连（Comma Splice）与因果逻辑跳跃修复】
审阅下列包含“encompassing”与“halve”的缺陷初稿，修正其中的【逗号粘连 / 连接词 on the contrary 误用】以及【把有限样本或仿真观察直接断言为无条件普遍因果律】两处错误，写出修正后的严谨英文句群：
Flawed Draft: *The review encompasses both experimental and observational approaches, on the contrary, halving the sampling interval doubles the sampling frequency., which proves 100% universal causality in all real-world regimes.*

### 第 33 题 `Q_D0108_33` 【主动与被动语态】（4 分）
- **训练目标**：结合及物性边界（not_applicable）与旧新信息焦点训练 ensemble 与 halve 的语态选择。
- **关联词条**：`V00893, V01158, V01260` | **语法点**：`G011, G036`
- **成分与语境提示**：及物性：not_applicable | 语态规则：G011 & G020（禁止机械转换或丢失情态限定）

【day_0108·信息焦点与语态转换 1】阅读下列包含“ensemble”（集成）与“halve”（减半）的学术表达：
Reference Sequence: (1) An ensemble forecast can combine information from several models. (2) The hypothetical grant would halve the registration fee.
改写要求：在严格保持原句时态、体、情态（如 may/can/should）及限定范围不变的前提下，根据“旧信息前置（Given-before-New）”与“施事责任明确性”原则，将第 (1) 句进行主动/被动语态转换（或重构为以核心研究对象为主语的紧凑句），使其与第 (2) 句自然衔接。

### 第 34 题 `Q_D0108_34` 【主动与被动语态】（4 分）
- **训练目标**：结合及物性边界（not_applicable）与旧新信息焦点训练 entangled 与 heuristic 的语态选择。
- **关联词条**：`V00894, V01174, V01810` | **语法点**：`G011, G036`
- **成分与语境提示**：及物性：not_applicable | 语态规则：G011 & G020（禁止机械转换或丢失情态限定）

【day_0108·信息焦点与语态转换 2】阅读下列包含“entangled”（交织的）与“heuristic”（启发式方法）的学术表达：
Reference Sequence: (1) The effects of income and neighbourhood conditions may be entangled in observational data. (2) The heuristic selects a feasible candidate but does not guarantee a global optimum.
改写要求：在严格保持原句时态、体、情态（如 may/can/should）及限定范围不变的前提下，根据“旧信息前置（Given-before-New）”与“施事责任明确性”原则，将第 (1) 句进行主动/被动语态转换（或重构为以核心研究对象为主语的紧凑句），使其与第 (2) 句自然衔接。

### 第 35 题 `Q_D0108_35` 【独立微型写作】（5 分）
- **训练目标**：在 AI/时序/生成建模/具身智能场景下运用 entropy、immanent 撰写零 AI 腔的技术微段落。
- **关联词条**：`V00896, V01218, V01817, V00995` | **语法点**：`G036, G032, G033`
- **成分与语境提示**：专业方向适配：ML / Time Series / Generative / Embodied AI | 语法：G032 & G035 | 模式：EP012

【day_0108·独立微型写作 1：深度学习 / 时间序列 / 生成模型 / 具身智能（Embodied AI）技术微段落（45–80 词，2–3 句）】
应用场景：顶会论文（NeurIPS / ICLR / CoRL / TPAMI）的方法描述、消融实验分析或口头技术报告（Tech Talk）。
写作要求：围绕以下候选目标词群中的至少 2–3 个词条（entropy（熵）、immanent（内在于某事物的）、parallel（平行的）、extrapolation（外推）），写出一段 2–3 句、紧凑自然的英文技术微段落：
1. 必须体现这些词在学术/技术语境下的准确含义与规约搭配（严防熟词生义误用）；
2. 主干清晰（主谓紧凑，长修饰语后置，彻底杜绝头重脚轻）；
3. 零 AI 腔（严禁使用 delve into / tapestry / groundbreaking / unparalleled 等空洞套话，直接用具体假设、分布、滞后项、轨迹或误差指标说话）。

### 第 36 题 `Q_D0108_36` 【独立微型写作】（5 分）
- **训练目标**：撰写融合 ergodicity、in charge of 与 parallel 的 3–5 句六级/雅思托福/演讲实证论证段落。
- **关联词条**：`V00909, V01244, V01818` | **语法点**：`G005, G028, G036`
- **成分与语境提示**：文体适配：CET-6 / IELTS / TOEFL Essay & Academic Speech | 语法：G005 & G036

【day_0108·独立微型写作 2：六级 / 雅思托福高分议论文与学术演讲（Tech Talk）完整段落写作（65–110 词，3–5 句）】
应用场景：英语六级（CET-6）、雅思大作文（IELTS Task 2）、托福独立写作或学术会议主题演讲。
写作要求：围绕“科技/教育/公共政策中的可及性、成本权衡与实证评估”主题，运用以下词群中的至少 3 个词条（ergodicity（遍历性）、in charge of（负责）、parallel（相似之处）），写出一段 3–5 句、逻辑严密的完整段落：
1. 结构必须包含：【明确主题句（Topic Sentence）】+【具体作用机制解释（Mechanism）】+【真实可感的具体实例/数据场景（Concrete Instance，严禁只有夸张口号而无实例）】+【让步或边界限定句（Concession/Qualification）】；
2. 运用语法规则【G005】（词形变化、词缀构词与词性语法槽位匹配（名、动、形、副））与表达模式【EP015】（章节过渡与Given-New指代衔接（This + 总结名词））；
3. 句式自然地道，杜绝死板模板句与头重脚轻。

