# DAY_0018 学术英语写作训练 V2.0（第 18 天 / 共 116 天）

- **所属阶段**：阶段 1：词汇激活、熟词生义破冰与句子主干剖析（Day 1–25）
- **训练模式**：8 大熟词生义/多义词群高密度激活 + 间隔复习
- **今日目标词条数**：27 | **预定复习词条数**：24 | **总题量**：36 题（总分 103 分）
- **核心语法与句法分析**：G028 学术段落逻辑架构：主题句—机制解释—实证/实例支撑—范围限定, G035 机器学习、时间序列、生成模型与具身智能（Embodied AI）的技术表达句法, G005 词形变化、词缀构词与词性语法槽位匹配（名、动、形、副）
- **核心表达模式**：EP002 精确区分可数样本量与不可数开销/证据, EP005 描述系统模块、数据集或分类体系的构成

## 一、今日核心词群与熟词生义（Polysemy）精讲

| 词条 ID | 词条 (Lemma) | 词性 | 熟词日常义 vs. 学术目标义 | 核心规约搭配 | 典型学术例句与句子成分主干 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `V01463` | **key** | adj. | **日常/基础**：已学基础义或同词元其他语境义（共关联 3 个词表词义单元）<br>**学术目标**：当前单元特定学术义：主要的；关键的（adj.） | `a key assumption` | A key assumption is that the measurement procedure remains unchanged.<br>*【紧凑主语】A key assumption is... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01464` | **key** | adj. | **日常/基础**：已学基础义或同词元其他语境义（共关联 3 个词表词义单元）<br>**学术目标**：当前单元特定学术义：关键的；主要的（adj.） | `key points` | The introduction identifies three key points for discussion.<br>*【紧凑主语】The introduction identifies three... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01465` | **key** | n. | **日常/基础**：已学基础义或同词元其他语境义（共关联 3 个词表词义单元）<br>**学术目标**：当前单元特定学术义：图例；符号说明（n.） | `a chart key` | The key identifies the colours used for each group.<br>*【紧凑主语】The key identifies the... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01471` | **label** | n./v. | **日常/基础**：基础字面义：标签<br>**学术目标**：多义项/多词性完整映射：标签；标注（n./v.） | `label the axes; a figure label` | Label each axis with its variable and unit.<br>*【紧凑主语】Label each axis with... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01472` | **laboratory** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：实验室（n.） | `in the laboratory; laboratory conditions` | The laboratory measurements may differ from field measurements.<br>*【紧凑主语】The laboratory measurements may... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01475` | **lag** | n.; v. | **日常/基础**：基础字面义：滞后<br>**学术目标**：多义项/多词性完整映射：滞后；时间上的间隔；落后（n.; v.） | `lag of one month; lag behind` | A lag of one month links the current observation to the observation from the preceding month.<br>*【紧凑主语】A lag of one... + 【核心谓语与宾补/状语后置扩展】全句共 16 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01476` | **lagged** | adj.; v.（过去式/过去分词） | **日常/基础**：基础字面义：滞后的<br>**学术目标**：多义项/多词性完整映射：滞后的；已落后的（adj.; v.（过去式/过去分词）） | `lagged observation; lagged dependent variable` | A lagged observation refers to a value measured at an earlier time.<br>*【紧凑主语】A lagged observation refers... + 【核心谓语与宾补/状语后置扩展】全句共 12 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01479` | **last** | adj. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：最后的（adj.） | `the last point` | The last point in the list concerns access.<br>*【紧凑主语】The last point in... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01483` | **late** | adj./adv. | **日常/基础**：基础字面义：较晚的<br>**学术目标**：多义项/多词性完整映射：较晚的；较晚地（adj./adv.） | `a late meeting; arrive late` | The meeting started late.<br>*【紧凑主语】The meeting started late.... + 【核心谓语与宾补/状语后置扩展】全句共 4 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01488` | **layer** | n. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：层（n.） | `a layer of rock` | The upper layer is thinner than the lower layer.<br>*【紧凑主语】The upper layer is... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01489` | **layer** | n. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：层；层次（n.） | `layers of soil` | The diagram shows several layers of soil around the object.<br>*【紧凑主语】The diagram shows several... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01495` | **lecture** | n. | **日常/基础**：基础字面义：讲座<br>**学术目标**：多义项/多词性完整映射：讲座；大型授课（n.） | `attend a lecture` | The lecture introduces the main assumptions of the method.<br>*【紧凑主语】The lecture introduces the... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01502` | **legend** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：图例（n.） | `the chart legend; a figure legend` | The legend identifies the two survey groups.<br>*【紧凑主语】The legend identifies the... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01506` | **liberal** | adj. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：支持开放和较大自由的（adj.） | `a liberal view of education` | A liberal view of education allows students to explore different disciplines.<br>*【紧凑主语】A liberal view of... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01512` | **likewise** | adv. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：同样地（adv.） | `likewise increased` | Costs increased; demand likewise increased.<br>*【紧凑主语】Costs increased; demand likewise... + 【核心谓语与宾补/状语后置扩展】全句共 5 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01513` | **limit** | n./v. | **日常/基础**：基础字面义：限制<br>**学术目标**：多义项/多词性完整映射：限制；限度（n./v.） | `a limit on; limit the scope` | The protocol places a limit on the number of responses.<br>*【紧凑主语】The protocol places a... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01516` | **link** | n. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：联系（n.） | `links between disciplines` | The course examines links between history and economics.<br>*【紧凑主语】The course examines links... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01517` | **link** | n./v. | **日常/基础**：已学基础义或同词元其他语境义（共关联 2 个词表词义单元）<br>**学术目标**：当前单元特定学术义：联系；关联（n./v.） | `a link between variables` | The study reports a link between the variables.<br>*【紧凑主语】The study reports a... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01518` | **list** | v. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：列出（v.） | `list hypotheses; list causes` | The appendix simply lists the exclusion criteria.<br>*【紧凑主语】The appendix simply lists... + 【核心谓语与宾补/状语后置扩展】全句共 7 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01523` | **loan** | n. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：贷款（n.） | `repay a loan; take out a loan` | The repayment terms of the loan should be checked before borrowing.<br>*【紧凑主语】The repayment terms of... + 【核心谓语与宾补/状语后置扩展】全句共 11 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01540` | **maintain** | v. | **日常/基础**：v. 保养维修<br>**学术目标**：v. ① 维持（系统性能或状态稳定，maintain performance）；② 坚持主张认为（The reviewer maintains that the evidence remains insufficient） | `maintain that` | The reviewer maintains that the evidence remains insufficient.<br>*【紧凑主语】The reviewer maintains that... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01541` | **maintain** | v. | **日常/基础**：v. 保养维修<br>**学术目标**：v. ① 维持（系统性能或状态稳定，maintain performance）；② 坚持主张认为（The reviewer maintains that the evidence remains insufficient） | `maintain performance` | The system maintained performance during the test period.<br>*【紧凑主语】The system maintained performance... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01542` | **maintain** | v. | **日常/基础**：v. 保养维修<br>**学术目标**：v. ① 维持（系统性能或状态稳定，maintain performance）；② 坚持主张认为（The reviewer maintains that the evidence remains insufficient） | `maintain a system; maintain that` | The authors maintain that the categories need revision.<br>*【紧凑主语】The authors maintain that... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01546` | **major** | adj. | **日常/基础**：基础字面义：主要的<br>**学术目标**：多义项/多词性完整映射：主要的；较大的（adj.） | `major role; major changes` | Funding is a major concern for the research team.<br>*【紧凑主语】Funding is a major... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01547` | **make** | v. | **日常/基础**：日常或通用英语近似概念<br>**学术目标**：精准学术定义：使（v.） | `make a task easier` | The checklist makes the task easier.<br>*【紧凑主语】The checklist makes the... + 【核心谓语与宾补/状语后置扩展】全句共 6 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01561` | **manipulate** | v. | **日常/基础**：v. 暗中操纵、篡改（贬义）<br>**学术目标**：v. ①（实验设计）系统改变、控制实验自变量（manipulate exposure time / room temperature）；②（具身智能/机器人）灵巧操作物体（robotic manipulation） | `manipulate a variable` | The researcher manipulated exposure time, not the outcome measure.<br>*【紧凑主语】The researcher manipulated exposure... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |
| `V01562` | **manipulate** | v. | **日常/基础**：v. 暗中操纵、篡改（贬义）<br>**学术目标**：v. ①（实验设计）系统改变、控制实验自变量（manipulate exposure time / room temperature）；②（具身智能/机器人）灵巧操作物体（robotic manipulation） | `manipulate a variable` | The experiment manipulated room temperature.<br>*【紧凑主语】The experiment manipulated room... + 【核心谓语与宾补/状语后置扩展】全句共 5 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。* |

### 辅助语境生词提前释义（不计入目标词掌握情况）
- **protocol**：研究方案；规程（n.）

## 二、36 道完整训练题（涵盖词形、搭配、辨析、去口语/去AI腔替换、尾重改写、中译英、语篇逻辑、语态与多文体微写作）

### 第 1 题 `Q_D0018_01` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 key (V01463) 的学术多义项与语境词形，并联动巩固 last (V01479)。
- **关联词条**：`V01463, V01479` | **语法点**：`G028`
- **成分与语境提示**：熟词生义与用法边界：一词多义与跨语境迁移对比：[V01463 adj.] 主要的；关键的（例：A key assumption is that the measurement procedure remains unchanged.）；[V01464 adj.] 关键的；主要的（例：The introduction identifies three key points for discussion.）；[V01465 n.] 图例；符号说明（例：The key identifies the colours used for each group.） | 本条用法约束：须具体指明假设。 | 句子成分结构：【紧凑主语】A key assumption is... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0018·词形与熟词生义激活 1】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“主要的”，adj.；注意区别于日常义：已学基础义或同词元其他语境义（共关联 3 个词表词义单元）），填写唯一准确的英文词形：
Sentence 1: A ________ assumption is that the measurement procedure remains unchanged. （句意：一项主要假设是测量流程保持不变。）
Sentence 2 (Companion Context with 'last'): The last point in the list concerns access.

### 第 2 题 `Q_D0018_02` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 key (V01464) 的学术多义项与语境词形，并联动巩固 late (V01483)。
- **关联词条**：`V01464, V01483` | **语法点**：`G028`
- **成分与语境提示**：熟词生义与用法边界：一词多义与跨语境迁移对比：[V01463 adj.] 主要的；关键的（例：A key assumption is that the measurement procedure remains unchanged.）；[V01464 adj.] 关键的；主要的（例：The introduction identifies three key points for discussion.）；[V01465 n.] 图例；符号说明（例：The key identifies the colours used for each group.） | 本条用法约束：评价“关键”应与具体目的关联。 | 句子成分结构：【紧凑主语】The introduction identifies three... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0018·词形与熟词生义激活 2】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“关键的”，adj.；注意区别于日常义：已学基础义或同词元其他语境义（共关联 3 个词表词义单元）），填写唯一准确的英文词形：
Sentence 1: The introduction identifies three ________ points for discussion. （句意：引言指出三个主要讨论点。）
Sentence 2 (Companion Context with 'late'): The meeting started late.

### 第 3 题 `Q_D0018_03` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 key (V01465) 的学术多义项与语境词形，并联动巩固 layer (V01488)。
- **关联词条**：`V01465, V01488` | **语法点**：`G028`
- **成分与语境提示**：熟词生义与用法边界：一词多义与跨语境迁移对比：[V01463 adj.] 主要的；关键的（例：A key assumption is that the measurement procedure remains unchanged.）；[V01464 adj.] 关键的；主要的（例：The introduction identifies three key points for discussion.）；[V01465 n.] 图例；符号说明（例：The key identifies the colours used for each group.） | 本条用法约束：这里与 legend 同义。 | 句子成分结构：【紧凑主语】The key identifies the... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0018·词形与熟词生义激活 3】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“图例”，n.；注意区别于日常义：已学基础义或同词元其他语境义（共关联 3 个词表词义单元）），填写唯一准确的英文词形：
Sentence 1: The ________ identifies the colours used for each group. （句意：图例说明各组使用的颜色。）
Sentence 2 (Companion Context with 'layer'): The upper layer is thinner than the lower layer.

### 第 4 题 `Q_D0018_04` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 label (V01471) 的学术多义项与语境词形，并联动巩固 layer (V01489)。
- **关联词条**：`V01471, V01489` | **语法点**：`G028`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：labelled 英式，labeled 美式。 | 句子成分结构：【紧凑主语】Label each axis with... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0018·词形与熟词生义激活 4】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“标签”，n./v.；注意区别于日常义：基础字面义：标签），填写唯一准确的英文词形：
Sentence 1: ________ each axis with its variable and unit. （句意：用变量名和单位标注每条坐标轴。）
Sentence 2 (Companion Context with 'layer'): The diagram shows several layers of soil around the object.

### 第 5 题 `Q_D0018_05` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 laboratory (V01472) 的学术多义项与语境词形，并联动巩固 lecture (V01495)。
- **关联词条**：`V01472, V01495` | **语法点**：`G028`
- **成分与语境提示**：熟词生义与用法边界：学术语境与搭配约束：laboratory 可作名词定语，不等于自然环境。 | 句子成分结构：【紧凑主语】The laboratory measurements may... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0018·词形与熟词生义激活 5】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“实验室”，n.；注意区别于日常义：日常或通用英语近似概念），填写唯一准确的英文词形：
Sentence 1: The ________ measurements may differ from field measurements. （句意：实验室测量结果可能与现场测量不同。）
Sentence 2 (Companion Context with 'lecture'): The lecture introduces the main assumptions of the method.

### 第 6 题 `Q_D0018_06` 【单词主动回忆和词形】（2 分）
- **训练目标**：激活 lag (V01475) 的学术多义项与语境词形，并联动巩固 legend (V01502)。
- **关联词条**：`V01475, V01502` | **语法点**：`G028`
- **成分与语境提示**：熟词生义与用法边界：词义与句法边界：时序 lag k 需说明采样频率，lagged variable 是滞后变量；动词 lag behind 指落后，不能与 lead 混同。 | 句子成分结构：【紧凑主语】A lag of one... + 【核心谓语与宾补/状语后置扩展】全句共 16 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

【day_0018·词形与熟词生义激活 6】阅读下列双句学术语境，根据第一句横线处的句子成分槽位与目标学术义（“滞后”，n.; v.；注意区别于日常义：基础字面义：滞后），填写唯一准确的英文词形：
Sentence 1: A ________ of one month links the current observation to the observation from the preceding month. （句意：一个月的滞后把当前观测与前一个月的观测联系起来。）
Sentence 2 (Companion Context with 'legend'): The legend identifies the two survey groups.

### 第 7 题 `Q_D0018_07` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 lagged 的自然搭配“lagged observation”并消除中式直译搭配错误。
- **关联词条**：`V01476, V01506` | **语法点**：`G028, G035`
- **成分与语境提示**：搭配类型：adj+noun | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“lagged observation”精确表述“滞后的；已落后的”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0018·常见学术搭配 1】根据搭配类型（adj+noun）与用法规范，使用目标词“lagged”（滞后的）的规约搭配补全并写出下列完整英文学术句（表达：“滞后观测指在更早时刻测得的值。”），使其与后句中的“liberal”（a liberal view of education）构成自然衔接：
待完成句语义：滞后观测指在更早时刻测得的值。（核心搭配提示：lagged observation）
后续衔接句：A liberal view of education allows students to explore different disciplines.

### 第 8 题 `Q_D0018_08` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 last 的自然搭配“the last point”并消除中式直译搭配错误。
- **关联词条**：`V01479, V01512` | **语法点**：`G028, G035`
- **成分与语境提示**：搭配类型：adj+noun | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“the last point”精确表述“最后的”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0018·常见学术搭配 2】根据搭配类型（adj+noun）与用法规范，使用目标词“last”（最后的）的规约搭配补全并写出下列完整英文学术句（表达：“清单中的最后一点涉及使用机会。”），使其与后句中的“likewise”（likewise increased）构成自然衔接：
待完成句语义：清单中的最后一点涉及使用机会。（核心搭配提示：the last point）
后续衔接句：Costs increased; demand likewise increased.

### 第 9 题 `Q_D0018_09` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 late 的自然搭配“a late meeting”并消除中式直译搭配错误。
- **关联词条**：`V01483, V01513` | **语法点**：`G028, G035`
- **成分与语境提示**：搭配类型：adj+noun | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“a late meeting”精确表述“较晚的；较晚地”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0018·常见学术搭配 3】根据搭配类型（adj+noun）与用法规范，使用目标词“late”（较晚的）的规约搭配补全并写出下列完整英文学术句（表达：“会议开始得较晚。”），使其与后句中的“limit”（a limit on）构成自然衔接：
待完成句语义：会议开始得较晚。（核心搭配提示：a late meeting）
后续衔接句：The protocol places a limit on the number of responses.

### 第 10 题 `Q_D0018_10` 【常见词汇搭配】（2 分）
- **训练目标**：掌握 layer 的自然搭配“a layer of rock”并消除中式直译搭配错误。
- **关联词条**：`V01488, V01516` | **语法点**：`G028, G035`
- **成分与语境提示**：搭配类型：noun+prep | 跨领域应用提示：在深度学习/时序预测/具身智能论文中，使用搭配“a layer of rock”精确表述“层”（例如描述分布假设、传感器时间序列滞后、物理运动约束或消融实验对比，直接陈述指标变化而不堆砌空洞形容词）。

【day_0018·常见学术搭配 4】根据搭配类型（noun+prep）与用法规范，使用目标词“layer”（层）的规约搭配补全并写出下列完整英文学术句（表达：“上层比下层薄。”），使其与后句中的“link”（links between disciplines）构成自然衔接：
待完成句语义：上层比下层薄。（核心搭配提示：a layer of rock）
后续衔接句：The course examines links between history and economics.

### 第 11 题 `Q_D0018_11` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 layer 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V01489, V01517` | **语法点**：`G028`
- **成分与语境提示**：目标句意：图示展示了器物周围的几层土。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0018·语境选词与多义/近义辨析 1】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 layers）：
Context: The diagram shows several ________ of soil around the object. Furthermore, regarding 'link', the study reports a link between the variables.

- A. capacity
- B. career
- C. layer
- D. case

### 第 12 题 `Q_D0018_12` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 lecture 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V01495, V01518` | **语法点**：`G028`
- **成分与语境提示**：目标句意：该讲座介绍该方法的主要假设。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0018·语境选词与多义/近义辨析 2】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 lecture）：
Context: The ________ introduces the main assumptions of the method. Furthermore, regarding 'list', the appendix simply lists the exclusion criteria.

- A. consequence
- B. contact
- C. content
- D. lecture

### 第 13 题 `Q_D0018_13` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 legend 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V01502, V01523` | **语法点**：`G028`
- **成分与语境提示**：目标句意：图例说明两个调查组。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0018·语境选词与多义/近义辨析 3】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 legend）：
Context: The ________ identifies the two survey groups. Furthermore, regarding 'loan', the repayment terms of the loan should be checked before borrowing.

- A. legend
- B. decade
- C. degree
- D. device

### 第 14 题 `Q_D0018_14` 【语境选词与近义词辨析】（2 分）
- **训练目标**：辨析 liberal 与同词性干扰词在语义范围、搭配及熟词生义上的差别。
- **关联词条**：`V01506, V01540` | **语法点**：`G028`
- **成分与语境提示**：目标句意：开放的教育观允许学生探索不同学科。 | 辨析焦点：语义范围、搭配规约与熟词生义边界

【day_0018·语境选词与多义/近义辨析 4】阅读下列包含上下文衔接的学术语境，从 A、B、C、D 中选出唯一在语义范围、介词配价与语域上契合横线处的最佳词元（若需屈折变化，句中实际词形为 liberal）：
Context: A ________ view of education allows students to explore different disciplines. Furthermore, regarding 'maintain', the reviewer maintains that the evidence remains insufficient.

- A. appropriate
- B. liberal
- C. approximate
- D. artificial

### 第 15 题 `Q_D0018_15` 【单词替换】（3 分）
- **训练目标**：用精准学术词 likewise (likewise) 替换英文初稿中的口语/模糊表达“in a rough way”。
- **关联词条**：`V01512, V01541` | **语法点**：`G028, G034`
- **成分与语境提示**：目标语义：成本增加了，需求也增加了。 | 熟词生义提醒：精准学术定义：同样地（adv.）

【day_0018·去口语化与精准单词替换 1】下列英文初稿句中画线部分（`in a rough way`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“likewise”的恰当词形，并写出完整修正句（需同时保留后半句中关于“maintain”的语境信息）：
English Draft: Costs increased; demand <u>in a rough way</u> increased. (Context note: The system maintained performance during the test period.)

### 第 16 题 `Q_D0018_16` 【单词替换】（3 分）
- **训练目标**：用精准学术词 limit (limit) 替换英文初稿中的口语/模糊表达“general thing or part”。
- **关联词条**：`V01513, V01542` | **语法点**：`G028, G034`
- **成分与语境提示**：目标语义：方案限制了答复数量。 | 熟词生义提醒：多义项/多词性完整映射：限制；限度（n./v.）

【day_0018·去口语化与精准单词替换 2】下列英文初稿句中画线部分（`general thing or part`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“limit”的恰当词形，并写出完整修正句（需同时保留后半句中关于“maintain”的语境信息）：
English Draft: The protocol places a <u>general thing or part</u> on the number of responses. (Context note: The authors maintain that the categories need revision.)

### 第 17 题 `Q_D0018_17` 【单词替换】（3 分）
- **训练目标**：用精准学术词 link (links) 替换英文初稿中的口语/模糊表达“general thing or part”。
- **关联词条**：`V01516, V01546` | **语法点**：`G028, G034`
- **成分与语境提示**：目标语义：课程考察历史与经济学之间的联系。 | 熟词生义提醒：当前单元特定学术义：联系（n.）

【day_0018·去口语化与精准单词替换 3】下列英文初稿句中画线部分（`general thing or part`）表达过于口语化或不够精确。请在不改变原句事实、否定与确定性程度的前提下，将其替换为今日目标词条“link”的恰当词形，并写出完整修正句（需同时保留后半句中关于“major”的语境信息）：
English Draft: The course examines <u>general thing or part</u> between history and economics. (Context note: Funding is a major concern for the research team.)

### 第 18 题 `Q_D0018_18` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“a link between variables”替换冗长生硬的英文草稿短语。
- **关联词条**：`V01517, V01547` | **语法点**：`G035, G034`
- **成分与语境提示**：目标规约短语：a link between variables | 配合表达模式：【EP002】精确区分可数样本量与不可数开销/证据

【day_0018·冗余/中式词组替换 1】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“link”的核心学术短语/搭配（“a link between variables”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The study reports a <u>make a basic handling in a general way regarding general thing or part</u> between the variables.
Companion Context ('make'): The checklist makes the task easier. （目标句意：研究报告了变量间的一种联系。）

### 第 19 题 `Q_D0018_19` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“list hypotheses”替换冗长生硬的英文草稿短语。
- **关联词条**：`V01518, V01561` | **语法点**：`G035, G034`
- **成分与语境提示**：目标规约短语：list hypotheses | 配合表达模式：【EP002】精确区分可数样本量与不可数开销/证据

【day_0018·冗余/中式词组替换 2】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“list”的核心学术短语/搭配（“list hypotheses”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The appendix simply <u>make a basic handling in a general way regarding do or handle</u> the exclusion criteria.
Companion Context ('manipulate'): The researcher manipulated exposure time, not the outcome measure. （目标句意：附录只列出了排除标准。）

### 第 20 题 `Q_D0018_20` 【词组与表达替换】（3 分）
- **训练目标**：使用地道学术搭配“repay a loan”替换冗长生硬的英文草稿短语。
- **关联词条**：`V01523, V01562` | **语法点**：`G035, G034`
- **成分与语境提示**：目标规约短语：repay a loan | 配合表达模式：【EP002】精确区分可数样本量与不可数开销/证据

【day_0018·冗余/中式词组替换 3】下列英文草稿句中画线部分存在“中式冗余堆砌（Over-expression）与搭配生硬”问题。请使用目标词条“loan”的核心学术短语/搭配（“repay a loan”）对其进行精简替换，写出地道、紧凑的完整英文句：
Awkward Draft: The repayment terms of the <u>make a basic handling in a general way regarding general thing or part</u> should be checked before borrowing.
Companion Context ('manipulate'): The experiment manipulated room temperature. （目标句意：借款前应核查贷款的偿还条款。）

### 第 21 题 `Q_D0018_21` 【句子改写】（3 分）
- **训练目标**：围绕 maintain 与 key 训练【消除头重脚轻（Top-Heavy Subject Elimination & End-Weight）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01540, V01463` | **语法点**：`G028, G032`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The reviewer maintains that... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：根据后接名词还是 that 从句区分“维持状态”与“坚持论点”。 | 词表跨单元多义对比：[V01540 v.] 坚持认为（例：The reviewer maintains that the evidence remains insufficient.）；[V01541 v.] 维持（例：The system maintained performance during the test period.）；[V01542 v.] 维持；主张（例：The authors maintain that the categories need revision.）

【day_0018·句子改写 1：消除头重脚轻（Top-Heavy Subject Elimination & End-Weight）】
Top-Heavy Draft: *The question of how the research team can properly handle the fact that the reviewer maintains that the evidence remains insufficient. in the experiment is what we look at.*
改写指令：上方草稿主语长达十余词而谓语仅以软弱的 is what we look at 收尾（典型头重脚轻）。请遵循【尾重原则（G032）】，直接以核心行动者或研究对象作简短主语，运用目标词“maintain”（搭配：maintain that）将其改写为紧凑、有力的学术句子（并结合“key”的语境边界）。

### 第 22 题 `Q_D0018_22` 【句子改写】（3 分）
- **训练目标**：围绕 maintain 与 key 训练【去除 AI 腔浮夸套话与过度表达（De-AI-ification & Concrete Precision）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01541, V01464` | **语法点**：`G028, G033`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The system maintained performance... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：根据后接名词还是 that 从句区分“维持状态”与“坚持论点”。 | 词表跨单元多义对比：[V01540 v.] 坚持认为（例：The reviewer maintains that the evidence remains insufficient.）；[V01541 v.] 维持（例：The system maintained performance during the test period.）；[V01542 v.] 维持；主张（例：The authors maintain that the categories need revision.）

【day_0018·句子改写 2：去除 AI 腔浮夸套话与过度表达（De-AI-ification & Concrete Precision）】
AI-Inflated Draft: *It is undeniably worth noting that our groundbreaking framework delves into the intricate realm of the problem and achieves an unparalleled breakthrough: The system maintained performance during the test period.*
改写指令：上方草稿充斥着典型 AI 废话套话（undeniably worth noting, groundbreaking, delves into the intricate realm, unparalleled breakthrough）。请删去所有无证据支撑的浮夸修饰（G033），保留全部真实事实、否定与限定条件，用目标词“maintain”写出零 AI 痕迹、克制精准的学术句子（关联词条：key）。

### 第 23 题 `Q_D0018_23` 【句子改写】（3 分）
- **训练目标**：围绕 maintain 与 key 训练【熟词生义激活与词性/句式转换改写（Polysemy & Syntactic Restructuring）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01542, V01465` | **语法点**：`G028, G021`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The authors maintain that... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：根据后接名词还是 that 从句区分“维持状态”与“坚持论点”。 | 词表跨单元多义对比：[V01540 v.] 坚持认为（例：The reviewer maintains that the evidence remains insufficient.）；[V01541 v.] 维持（例：The system maintained performance during the test period.）；[V01542 v.] 维持；主张（例：The authors maintain that the categories need revision.）

【day_0018·句子改写 3：熟词生义激活与词性/句式转换改写（Polysemy & Syntactic Restructuring）】
Source Statement: The authors maintain that the categories need revision. （中文句意：作者主张这些类别需要修订。）
改写指令：在不改变原句任何事实、时间、程度和谨慎语气（hedging）的前提下，利用目标词“maintain”（注意其学术义：v. ① 维持（系统性能或状态稳定，maintain performance）；② 坚持主张认为（The reviewer maintains that the evidence remains insufficient））及协同词“key”，通过调整句法结构（如前置条件状语、转换词性或改写同位/修饰结构）写出语义完全等价的另一地道版本。

### 第 24 题 `Q_D0018_24` 【句子改写】（3 分）
- **训练目标**：围绕 major 与 label 训练【主从复合句与紧凑介词/分词短语或倒装转换（Clause Compression & Inversion）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01546, V01471` | **语法点**：`G028, G018`
- **成分与语境提示**：核心成分拆解：【紧凑主语】Funding is a major... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：词义与句法边界：上述搭配通常也可用反义词 minor。

【day_0018·句子改写 4：主从复合句与紧凑介词/分词短语或倒装转换（Clause Compression & Inversion）】
Verbose Draft: *When we consider the context of the analysis, it is true that funding is a major concern for the research team.*
改写指令：消除句首拖沓的从句，运用目标词“major”（搭配：major role）与紧凑的学术句法（G018/G031），将其改写为主干突出、主谓紧凑的单句（关联复习/协同词：label），严禁产生悬垂修饰或增删原意。

### 第 25 题 `Q_D0018_25` 【句子改写】（3 分）
- **训练目标**：围绕 make 与 laboratory 训练【跨场景语域迁移改写（AI/时序/具身智能论文 vs. 六级/雅思托福/演讲）】，保持语义守恒与句子成分平衡。
- **关联词条**：`V01547, V01472` | **语法点**：`G028, G036`
- **成分与语境提示**：核心成分拆解：【紧凑主语】The checklist makes the... + 【核心谓语与宾补/状语后置扩展】全句共 6 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。 | 用法与多义边界：学术语境与搭配约束：make + 宾语 + 形容词；使某人做可用省to不定式。

【day_0018·句子改写 5：跨场景语域迁移改写（AI/时序/具身智能论文 vs. 六级/雅思托福/演讲）】
Base Observation: The checklist makes the task easier. (Paired concept: 'laboratory' — The laboratory measurements may differ from field measurements.)
改写指令：将上方两个观察整合或改写为一句逻辑严密的复合句或分号衔接句，同时准确体现“make”与“laboratory”的核心用法，确保指代清晰且标点规范（杜绝 Comma Splice）。

### 第 26 题 `Q_D0018_26` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 manipulate (manipulate a variable) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V01561, V01475` | **语法点**：`G035, G031`
- **成分与语境提示**：多义与用法提示：在实验科学中指“控制改变自变量”；在具身智能（Embodied AI）中指“机械臂/灵巧手操作物体”，均为核心中性技术词！ | 词表跨单元多义对比：[V01561 v.] 操纵；改变实验变量（例：The researcher manipulated exposure time, not the outcome measure.）；[V01562 v.] 操纵；改变研究变量（例：The experiment manipulated room temperature.） | 语法焦点：【G031】句子成分精细剖析（主、谓、宾、表、定、状、补、同位语）与核心主干定位

【day_0018·中译英与句子成分构建 1（实证研究方法与数据核查场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“manipulate”的学术义“操纵”及其搭配“manipulate a variable”，并兼顾协同词“lag”的语境标准）：
中文题干：研究人员改变了暴露时间，未改变结果测量。
句子成分构建提示：【紧凑主语】The researcher manipulated exposure... + 【核心谓语与宾补/状语后置扩展】全句共 9 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 27 题 `Q_D0018_27` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 manipulate (manipulate a variable) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V01562, V01476` | **语法点**：`G035`
- **成分与语境提示**：多义与用法提示：在实验科学中指“控制改变自变量”；在具身智能（Embodied AI）中指“机械臂/灵巧手操作物体”，均为核心中性技术词！ | 词表跨单元多义对比：[V01561 v.] 操纵；改变实验变量（例：The researcher manipulated exposure time, not the outcome measure.）；[V01562 v.] 操纵；改变研究变量（例：The experiment manipulated room temperature.） | 语法焦点：【G035】机器学习、时间序列、生成模型与具身智能（Embodied AI）的技术表达句法

【day_0018·中译英与句子成分构建 2（机器学习、时间序列与生成模型场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“manipulate”的学术义“操纵”及其搭配“manipulate a variable”，并兼顾协同词“lagged”的语境标准）：
中文题干：实验改变了室温这一变量。
句子成分构建提示：【紧凑主语】The experiment manipulated room... + 【核心谓语与宾补/状语后置扩展】全句共 5 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 28 题 `Q_D0018_28` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 key (a key assumption) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V01463, V01479` | **语法点**：`G035, G032`
- **成分与语境提示**：多义与用法提示：一词多义与跨语境迁移对比：[V01463 adj.] 主要的；关键的（例：A key assumption is that the measurement procedure remains unchanged.）；[V01464 adj.] 关键的；主要的（例：The introduction identifies three key points for discussion.）；[V01465 n.] 图例；符号说明（例：The key identifies the colours used for each group.） | 本条用法约束：须具体指明假设。 | 语法焦点：【G032】消除“头重脚轻（Top-Heavy Subject）”与遵循尾重原则（End-Weight Principle）

【day_0018·中译英与句子成分构建 3（具身智能（Embodied AI）、传感器与系统约束场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“key”的学术义“主要的”及其搭配“a key assumption”，并兼顾协同词“last”的语境标准）：
中文题干：一项主要假设是测量流程保持不变。
句子成分构建提示：【紧凑主语】A key assumption is... + 【核心谓语与宾补/状语后置扩展】全句共 10 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 29 题 `Q_D0018_29` 【中译英与主动表达】（3 分）
- **训练目标**：运用句子成分分析法与 key (key points) 完成地道、无头重脚轻的中译英输出。
- **关联词条**：`V01464, V01483` | **语法点**：`G035, G036`
- **成分与语境提示**：多义与用法提示：一词多义与跨语境迁移对比：[V01463 adj.] 主要的；关键的（例：A key assumption is that the measurement procedure remains unchanged.）；[V01464 adj.] 关键的；主要的（例：The introduction identifies three key points for discussion.）；[V01465 n.] 图例；符号说明（例：The key identifies the colours used for each group.） | 本条用法约束：评价“关键”应与具体目的关联。 | 语法焦点：【G036】跨场景文体适配：顶会论文、学术演讲（Tech Talk）、个人陈述（SoP）与六级/雅思托福高分议论文

【day_0018·中译英与句子成分构建 4（六级/雅思托福高分议论文与学术演讲（Tech Talk）场景）】
请将下列中文学术陈述翻译为自然、地道、零 AI 痕迹的英文句子（必须准确使用“key”的学术义“关键的”及其搭配“key points”，并兼顾协同词“late”的语境标准）：
中文题干：引言指出三个主要讨论点。
句子成分构建提示：【紧凑主语】The introduction identifies three... + 【核心谓语与宾补/状语后置扩展】全句共 8 词，主谓衔接紧凑，将修饰与限定条件置于谓语之后，符合英语尾重原则（End-Weight），无冗余 AI 套话。

### 第 30 题 `Q_D0018_30` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：用包含 key 与 lecture 的具体机制与实例替换“只有夸张而无实例”的空洞断言。
- **关联词条**：`V01465, V01495, V01540` | **语法点**：`G028, G033`
- **成分与语境提示**：核心原则：用具体算子、样本条件与可核验实例替代空洞形容词（G033 & G028）

【day_0018·逻辑衔接与语篇组织 1：根治“只有夸张而无实例/具体指标”的空洞段落】
下列初稿开头句犯了“只有空洞夸张（hollow hyperbole）而无具体机制与实证支撑”的典型写作病灶：
Hollow Draft: *Our method is extremely great and solves all problems in a revolutionary way.*
任务要求：请摒弃上述空洞吹嘘，结合目标词条“key”（图例）与“lecture”（讲座），写出一段 2–3 句、有具体方法机制与明确适用范围的实证分析或议论文支撑句群（可用于 AI/时序/具身智能论文或六级/雅思托福正文段）。

### 第 31 题 `Q_D0018_31` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：通过含 label 与 legend 的四句重排，掌握 Given-New 信息契约与 This + 总结名词衔接。
- **关联词条**：`V01471, V01502, V01541` | **语法点**：`G035, G009`
- **成分与语境提示**：语篇衔接规则：旧信息前置（Given-before-New）与精确指代回指

【day_0018·逻辑衔接与语篇组织 2：段落句子排序与 Given-New 指代链分析】
将下列包含目标词“label”与“legend”的 4 个句子按“旧信息在前、新信息在后（Given-New Contract）”的指代逻辑排成连贯段落，并写出排序结果及关键回指词（如 This setup / these two findings）：
(1) When examining the empirical outputs, a second consideration arises: The legend identifies the two survey groups.
(2) Taken together, these two findings indicate that both protocol design and scope constraints must be reported transparently.
(3) First, we specify the methodological setup: Label each axis with its variable and unit.
(4) This setup ensures that the evaluation criteria remain consistent across all test runs.

### 第 32 题 `Q_D0018_32` 【逻辑衔接和语篇组织】（4 分）
- **训练目标**：修复含 laboratory 与 liberal 段落中的逗号粘连、连接词误用与因果外推跳跃。
- **关联词条**：`V01472, V01506, V01542` | **语法点**：`G005, G023`
- **成分与语境提示**：综合诊断：标点规范（G023）+ 连接词精确语义（G028）+ 相关与因果边界（G026）

【day_0018·逻辑衔接与语篇组织 3：标点粘连（Comma Splice）与因果逻辑跳跃修复】
审阅下列包含“laboratory”与“liberal”的缺陷初稿，修正其中的【逗号粘连 / 连接词 on the contrary 误用】以及【把有限样本或仿真观察直接断言为无条件普遍因果律】两处错误，写出修正后的严谨英文句群：
Flawed Draft: *The laboratory measurements may differ from field measurements, on the contrary, a liberal view of education allows students to explore different disciplines., which proves 100% universal causality in all real-world regimes.*

### 第 33 题 `Q_D0018_33` 【主动与被动语态】（4 分）
- **训练目标**：结合及物性边界（intransitive）与旧新信息焦点训练 lag 与 likewise 的语态选择。
- **关联词条**：`V01475, V01512, V01546` | **语法点**：`G011, G028`
- **成分与语境提示**：及物性：intransitive | 语态规则：G011 & G020（禁止机械转换或丢失情态限定）

【day_0018·语态与及物性边界 1】目标词条“lag”（滞后）在句中属于不及物或状态性结构（intransitive）。请改正下列误用被动语态的病句，并结合协同词“likewise”写出语法正确、主干清晰的主动语态双句序列：
Ungrammatical Passive Draft: *In this experiment, the phenomenon of 'lag' was consisted / was occurred by the system, and costs increased; demand likewise increased.*

### 第 34 题 `Q_D0018_34` 【主动与被动语态】（4 分）
- **训练目标**：结合及物性边界（not_applicable）与旧新信息焦点训练 lagged 与 limit 的语态选择。
- **关联词条**：`V01476, V01513, V01547` | **语法点**：`G011, G028`
- **成分与语境提示**：及物性：not_applicable | 语态规则：G011 & G020（禁止机械转换或丢失情态限定）

【day_0018·信息焦点与语态转换 2】阅读下列包含“lagged”（滞后的）与“limit”（限制）的学术表达：
Reference Sequence: (1) A lagged observation refers to a value measured at an earlier time. (2) The protocol places a limit on the number of responses.
改写要求：在严格保持原句时态、体、情态（如 may/can/should）及限定范围不变的前提下，根据“旧信息前置（Given-before-New）”与“施事责任明确性”原则，将第 (1) 句进行主动/被动语态转换（或重构为以核心研究对象为主语的紧凑句），使其与第 (2) 句自然衔接。

### 第 35 题 `Q_D0018_35` 【独立微型写作】（5 分）
- **训练目标**：在 AI/时序/生成建模/具身智能场景下运用 last、link 撰写零 AI 腔的技术微段落。
- **关联词条**：`V01479, V01516, V01561, V01495` | **语法点**：`G028, G032, G033`
- **成分与语境提示**：专业方向适配：ML / Time Series / Generative / Embodied AI | 语法：G032 & G035 | 模式：EP002

【day_0018·独立微型写作 1：深度学习 / 时间序列 / 生成模型 / 具身智能（Embodied AI）技术微段落（45–80 词，2–3 句）】
应用场景：顶会论文（NeurIPS / ICLR / CoRL / TPAMI）的方法描述、消融实验分析或口头技术报告（Tech Talk）。
写作要求：围绕以下候选目标词群中的至少 2–3 个词条（last（最后的）、link（联系）、manipulate（操纵）、lecture（讲座）），写出一段 2–3 句、紧凑自然的英文技术微段落：
1. 必须体现这些词在学术/技术语境下的准确含义与规约搭配（严防熟词生义误用）；
2. 主干清晰（主谓紧凑，长修饰语后置，彻底杜绝头重脚轻）；
3. 零 AI 腔（严禁使用 delve into / tapestry / groundbreaking / unparalleled 等空洞套话，直接用具体假设、分布、滞后项、轨迹或误差指标说话）。

### 第 36 题 `Q_D0018_36` 【独立微型写作】（5 分）
- **训练目标**：撰写融合 late、link 与 arise 的 3–5 句六级/雅思托福/演讲实证论证段落。
- **关联词条**：`V01483, V01517, V01562, V00174` | **语法点**：`G035, G028, G036`
- **成分与语境提示**：文体适配：CET-6 / IELTS / TOEFL Essay & Academic Speech | 语法：G035 & G036

【day_0018·独立微型写作 2：六级 / 雅思托福高分议论文与学术演讲（Tech Talk）完整段落写作（65–110 词，3–5 句）】
应用场景：英语六级（CET-6）、雅思大作文（IELTS Task 2）、托福独立写作或学术会议主题演讲。
写作要求：围绕“科技/教育/公共政策中的可及性、成本权衡与实证评估”主题，运用以下词群中的至少 3 个词条（late（较晚的）、link（联系）、manipulate（操纵）、arise（出现）），写出一段 3–5 句、逻辑严密的完整段落：
1. 结构必须包含：【明确主题句（Topic Sentence）】+【具体作用机制解释（Mechanism）】+【真实可感的具体实例/数据场景（Concrete Instance，严禁只有夸张口号而无实例）】+【让步或边界限定句（Concession/Qualification）】；
2. 运用语法规则【G035】（机器学习、时间序列、生成模型与具身智能（Embodied AI）的技术表达句法）与表达模式【EP005】（描述系统模块、数据集或分类体系的构成）；
3. 句式自然地道，杜绝死板模板句与头重脚轻。

